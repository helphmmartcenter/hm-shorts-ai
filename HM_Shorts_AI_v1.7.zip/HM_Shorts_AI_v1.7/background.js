// ===== HM Shorts AI - Background Service Worker =====
// Version: 1.6

// ===== KEEP-ALIVE + NET CHECK via chrome.alarms =====
chrome.alarms.create('HM_KEEPALIVE', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== 'HM_KEEPALIVE') return;
  if (state.isRunning && !state.softStop) {
    checkNetStatus();
  }
});

// ===== FETCH-BASED NET DETECTION (reliable) =====
async function checkNetStatus() {
  try {
    // Chhoti fetch — agar kaam kare to net hai
    const res = await fetch('https://www.gstatic.com/generate_204', {
      method: 'HEAD', cache: 'no-store', mode: 'no-cors'
    });
    // Net hai
    if (state.waitingForNet) {
      handleNetBack();
    }
  } catch (e) {
    // Net nahi
    if (!state.waitingForNet && state.isRunning && !state.softStop) {
      state.waitingForNet = true;
      addLog('⚠ Network lost — waiting for reconnect...', 'err');
      notify('HM_STATUS', { text: 'Waiting for network...', dot: 'orange' });
      saveStatus('Waiting for network...', 'orange');
    }
  }
}

function handleNetBack() {
  if (!state.waitingForNet) return;
  state.waitingForNet = false;
  if (!state.isRunning || state.softStop) return;
  const skippedTitle = (state.scriptTitles && state.scriptTitles[state.currentIndex]) || ('Script #' + (state.currentIndex + 1));
  state.sessionStats.errors.push({ title: skippedTitle, error: 'Network issue — skipped' });
  addLog('📶 Network restored! Skipping "' + skippedTitle + '" — starting next...', 'info');
  notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
  notify('HM_STATUS', { text: 'Network restored — continuing...', dot: 'green' });
  state.waitingForVideo = false;
  saveProgress();
  moveNext();
}

let state = {
  isRunning: false,
  softStop: false,
  waitingForNet: false,
  scripts: [],
  scriptTitles: [],
  settings: {},
  currentIndex: 0,
  tabId: null,
  waitingForVideo: false,
  downloadRetries: 0,
  sessionId: null,
  sessionStats: { done: 0, errors: [] },
  sessionStartTime: null
};

chrome.action.onClicked.addListener(tab => {
  chrome.sidePanel.open({ windowId: tab.windowId });
});

// ===== LOG HELPER — saves to storage + notifies UI =====
function addLog(text, cls) {
  const t = new Date().toLocaleTimeString();
  const line = { t, text, cls: cls || '' };
  notify('HM_LOG', { text, cls: cls || '' });
  // Save to storage
  chrome.storage.local.get(['hmLog'], r => {
    const log = r.hmLog || [];
    log.push(line);
    if (log.length > 100) log.splice(0, log.length - 100);
    chrome.storage.local.set({ hmLog: log });
  });
}

// ===== MESSAGE HANDLER =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'HM_START') {
    state.scripts = msg.scripts;
    state.scriptTitles = msg.scriptTitles || [];
    state.settings = msg.settings;
    // P3 FIX: Resume → next script (currentIndex already incremented before stop)
    state.currentIndex = msg.resumeIndex || 0;
    state.isRunning = true;
    state.softStop = false;
    state.waitingForNet = false;
    state.waitingForVideo = false;
    state.downloadRetries = 0;
    state.sessionId = msg.sessionId || Date.now();
    state.sessionStartTime = msg.sessionStartTime || Date.now();
    state.sessionStats = { done: msg.resumeDone || 0, errors: msg.resumeErrors || [] };
    saveProgress();
    saveButtonState('running');
    saveStatus('Running...', 'green');
    processNext();
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_SOFT_STOP') {
    state.softStop = true;
    state.isRunning = false;
    addLog('⏸ Stopping — waiting for current task to complete...', 'info');
    saveButtonState('stopped');
    saveStatus('Stopping...', 'orange');
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_GET_STATE') {
    sendResponse({
      isRunning: state.isRunning,
      softStop: state.softStop,
      currentIndex: state.currentIndex,
      total: state.scripts.length
    });
  }

  if (msg.action === 'HM_VIDEO_FOUND') {
    if (state.waitingForVideo) {
      state.waitingForVideo = false;
      handleVideoFound(msg.videoUrl, msg.tabTitle);
    }
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_CONTENT_ERROR') {
    addLog('❌ ' + msg.error, 'err');
    const skippedTitle = (state.scriptTitles && state.scriptTitles[state.currentIndex]) || ('Script #' + (state.currentIndex + 1));
    state.sessionStats.errors.push({ title: skippedTitle, error: msg.error });
    notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
    if (state.isRunning) setTimeout(() => moveNext(), 3000);
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_GET_PROGRESS') {
    chrome.storage.local.get(['hmProgress'], r => {
      sendResponse({ progress: r.hmProgress || null });
    });
    return true;
  }

  if (msg.action === 'HM_GET_HISTORY') {
    chrome.storage.local.get(['hmHistory'], r => {
      sendResponse({ history: r.hmHistory || [] });
    });
    return true;
  }

  if (msg.action === 'HM_CLEAR_HISTORY') {
    chrome.storage.local.remove(['hmHistory'], () => sendResponse({ ok: true }));
    return true;
  }

  return true;
});

// ===== STATE SAVE HELPERS =====
function saveButtonState(s) {
  chrome.storage.local.set({ hmButtonState: s });
}

function saveStatus(text, dot) {
  chrome.storage.local.set({ hmStatus: { text, dot } });
}

// ===== PROGRESS =====
function saveProgress() {
  chrome.storage.local.set({
    hmProgress: {
      currentIndex: state.currentIndex,
      total: state.scripts.length,
      scripts: state.scripts,
      scriptTitles: state.scriptTitles,
      settings: state.settings,
      sessionId: state.sessionId,
      sessionStartTime: state.sessionStartTime,
      sessionStats: state.sessionStats,
      savedAt: Date.now()
    }
  });
}

function clearProgress() {
  chrome.storage.local.remove(['hmProgress', 'hmLog', 'hmStatus', 'hmButtonState']);
}

// ===== HISTORY =====
function saveSessionToHistory(status, totalTime) {
  if (!state.sessionId) return;
  const session = {
    id: state.sessionId,
    date: new Date().toLocaleDateString(),
    time: new Date().toLocaleTimeString(),
    total: state.scripts.length,
    done: state.sessionStats.done,
    errors: state.sessionStats.errors,
    status, totalTime: totalTime || 0
  };
  chrome.storage.local.get(['hmHistory'], r => {
    const history = r.hmHistory || [];
    history.unshift(session);
    if (history.length > 30) history.splice(30);
    chrome.storage.local.set({ hmHistory: history });
    notify('HM_HISTORY_UPDATED', {});
  });
}

// ===== CORE PROCESS =====
async function processNext() {
  if (!state.isRunning || state.softStop || state.waitingForNet) return;

  const idx = state.currentIndex;
  const total = state.scripts.length;

  if (idx >= total) {
    state.isRunning = false;
    const totalTime = state.sessionStartTime ? Math.round((Date.now() - state.sessionStartTime) / 1000) : 0;
    saveSessionToHistory('done', totalTime);
    clearProgress();
    saveButtonState('done');
    saveStatus('All Done! ✓', 'green');
    notify('HM_DONE', { total, done: state.sessionStats.done, errors: state.sessionStats.errors.length, totalTime });
    return;
  }

  state.downloadRetries = 0;
  saveProgress();

  const script = state.scripts[idx];
  const statusText = 'Script ' + (idx+1) + '/' + total;
  notify('HM_STATUS', { text: statusText, dot: 'green' });
  saveStatus(statusText, 'green');

  // P4 FIX: Progress correct — done scripts count
  notify('HM_PROGRESS', { done: state.sessionStats.done, total, currentIdx: idx });
  addLog('▶ Script ' + (idx+1) + ': ' + script.substring(0,40) + '...', 'info');

  try {
    // P6 FIX: Resume par page refresh nahi — tab already open ho to seedha inject
    const tabs = await chrome.tabs.query({ url: 'https://geminigen.ai/*' });
    let targetTab;

    if (tabs.length > 0) {
      targetTab = tabs[0];
      state.tabId = targetTab.id;
      const currentTabUrl = targetTab.url || '';
      // Agar already /veo par hai to reload nahi — seedha inject
      if (currentTabUrl.includes('/veo') && !currentTabUrl.includes('generation_uuid')) {
        await chrome.tabs.update(state.tabId, { active: true });
        await sleep(800);
      } else {
        // generation_uuid page par hai ya kuch aur — fresh /veo par jao
        await chrome.tabs.update(state.tabId, { url: 'https://geminigen.ai/veo', active: true });
        await waitForTabLoad(state.tabId);
        await sleep(2000);
      }
    } else {
      targetTab = await chrome.tabs.create({ url: 'https://geminigen.ai/veo', active: true });
      state.tabId = targetTab.id;
      await waitForTabLoad(state.tabId);
      await sleep(3000);
    }

    await runAutomation(script);

  } catch (e) {
    addLog('❌ Page error: ' + e.message, 'err');
    if (state.isRunning && !state.softStop) setTimeout(() => moveNext(), 5000);
  }
}

function waitForTabLoad(tabId) {
  return new Promise(resolve => {
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        resolve();
      }
    }
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(resolve, 15000);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function runAutomation(scriptText) {
  if (!state.isRunning || state.softStop) return;
  try {
    await chrome.scripting.executeScript({
      target: { tabId: state.tabId },
      func: automationScript,
      args: [scriptText, state.settings]
    });
    state.waitingForVideo = true;
    addLog('⏳ Waiting for video to generate...', 'info');
    notify('HM_STATUS', { text: 'Generating video...', dot: 'orange' });
    saveStatus('Generating video...', 'orange');
  } catch (e) {
    addLog('❌ Injection failed: ' + e.message, 'err');
    if (state.isRunning && !state.softStop) setTimeout(() => moveNext(), 5000);
  }
}

function automationScript(scriptText, settings) {
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  async function run() {
    try {
      let textarea = null;
      const textareaSelectors = [
        'textarea[placeholder*="Describe"]','textarea[placeholder*="describe"]',
        'textarea[placeholder*="video"]','textarea[placeholder*="generate"]',
        'textarea[placeholder*="Generate"]','textarea',
      ];
      for (const sel of textareaSelectors) { textarea = document.querySelector(sel); if (textarea) break; }
      if (!textarea) textarea = document.querySelector('[contenteditable="true"]');
      if (!textarea) { chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Input field not found on page' }); return; }

      textarea.focus(); await sleep(300);
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
      if (nativeSetter && nativeSetter.set) { nativeSetter.set.call(textarea, ''); } else { textarea.value = ''; }
      textarea.dispatchEvent(new Event('input', { bubbles: true })); await sleep(200);
      if (nativeSetter && nativeSetter.set) { nativeSetter.set.call(textarea, scriptText); } else { textarea.value = scriptText; }
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      textarea.dispatchEvent(new Event('change', { bubbles: true })); await sleep(500);

      const btnSelectors = ['button[type="submit"]','button[aria-label*="enerate"]','button[aria-label*="send"]','button[aria-label*="Send"]','button[title*="enerate"]','button[class*="send"]','button[class*="submit"]','button[class*="generate"]','form button:last-child','button svg'];
      let genBtn = null;
      for (const sel of btnSelectors) { const el = document.querySelector(sel); if (el) { genBtn = el.closest('button') || el; break; } }
      if (genBtn) { genBtn.click(); await sleep(500); }
      else { textarea.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, ctrlKey: false, bubbles: true })); await sleep(500); }

      const oldUrl = window.location.href;
      let urlPollCount = 0;
      const urlPollInterval = setInterval(() => {
        urlPollCount++;
        if (urlPollCount > 30) { clearInterval(urlPollInterval); chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation did not start (30s timeout)' }); return; }
        const currentUrl = window.location.href;
        if ((currentUrl !== oldUrl) && currentUrl.includes('generation_uuid')) {
          clearInterval(urlPollInterval);
          let pollCount = 0;
          const pollInterval = setInterval(async () => {
            pollCount++;
            if (pollCount > 150) { clearInterval(pollInterval); chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Video generation timeout (7.5 min)' }); return; }
            const bodyText = document.body.innerText || '';
            if (bodyText.includes('being created') || bodyText.includes('AI magic') || bodyText.includes('being generated')) return;
            const downloadSelectors = ['a[download]','button[aria-label*="ownload"]','button[title*="ownload"]','button[class*="download"]','[data-action*="download"]'];
            let downloadEl = null;
            for (const sel of downloadSelectors) { downloadEl = document.querySelector(sel); if (downloadEl) break; }
            const videoEl = document.querySelector('video[src]:not([src=""])');
            if (downloadEl || videoEl) {
              clearInterval(pollInterval);
              let videoUrl = null;
              const pageTitle = document.title || 'video';
              if (downloadEl) { if (downloadEl.tagName === 'A' && downloadEl.href) videoUrl = downloadEl.href; await sleep(300); downloadEl.click(); await sleep(1000); }
              if (!videoUrl && videoEl) videoUrl = videoEl.src;
              if (!videoUrl) { const allVideos = document.querySelectorAll('video'); for (const v of allVideos) { if (v.src && v.src !== '') { videoUrl = v.src; break; } } }
              chrome.runtime.sendMessage({ action: 'HM_VIDEO_FOUND', videoUrl, tabTitle: pageTitle });
            }
          }, 3000);
        }
      }, 1000);
    } catch (err) { chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: err.message }); }
  }
  run();
}

// ===== DOWNLOAD =====
function handleVideoFound(videoUrl, tabTitle) {
  const folder = state.settings.folderName || 'HM_Shorts_AI_Videos';
  const ts = Date.now();
  let rawTitle = (state.scriptTitles && state.scriptTitles[state.currentIndex]) || '';
  let safeTitle = rawTitle.trim().replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, '_').substring(0, 80);
  const filename = folder + '/' + (safeTitle || 'video_' + (state.currentIndex + 1) + '_' + ts) + '.mp4';
  const retryMsg = state.downloadRetries > 0 ? ' (retry ' + state.downloadRetries + '/3)' : '';
  addLog('⬇ Downloading video #' + (state.currentIndex+1) + retryMsg, 'dl');

  if (!videoUrl) {
    const title = rawTitle || ('Script #' + (state.currentIndex + 1));
    state.sessionStats.errors.push({ title, error: 'Video URL not found' });
    addLog('⚠ Video URL not found — skipping', 'err');
    notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
    saveProgress(); moveNext(); return;
  }

  chrome.downloads.download({ url: videoUrl, filename, saveAs: false }, downloadId => {
    if (chrome.runtime.lastError || !downloadId) {
      if (state.downloadRetries < 3) {
        state.downloadRetries++;
        addLog('⚠ Download failed (' + state.downloadRetries + '/3) retrying...', 'info');
        setTimeout(() => handleVideoFound(videoUrl, tabTitle), 5000);
      } else {
        const title = rawTitle || ('Script #' + (state.currentIndex + 1));
        state.sessionStats.errors.push({ title, error: 'Download failed 3 times' });
        addLog('❌ 3 retries failed — skipping: ' + (rawTitle || 'Script #' + (state.currentIndex+1)), 'err');
        notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
        saveProgress(); moveNext();
      }
      return;
    }

    addLog('📥 Downloading... waiting for completion', 'dl');
    function onDownloadChanged(delta) {
      if (delta.id !== downloadId) return;
      if (delta.state && delta.state.current === 'complete') {
        chrome.downloads.onChanged.removeListener(onDownloadChanged);
        state.sessionStats.done++;
        addLog('✅ Download complete: ' + filename, 'ok');
        notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
        // P3 FIX: Next script index save karo PEHLE — resume next se shuru ho
        state.currentIndex++;
        saveProgress();
        if (state.softStop) {
          saveButtonState('stopped');
          saveStatus('Stopped', 'red');
          notify('HM_SOFT_STOPPED', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
          return;
        }
        // moveNext already increments — undo our increment
        state.currentIndex--;
        moveNext();
      }
      if (delta.state && delta.state.current === 'interrupted') {
        chrome.downloads.onChanged.removeListener(onDownloadChanged);
        if (state.downloadRetries < 3) {
          state.downloadRetries++;
          addLog('⚠ Download interrupted (' + state.downloadRetries + '/3)...', 'info');
          setTimeout(() => handleVideoFound(videoUrl, tabTitle), 5000);
        } else {
          const title = rawTitle || ('Script #' + (state.currentIndex + 1));
          state.sessionStats.errors.push({ title, error: 'Download interrupted' });
          addLog('❌ 3 retries failed — skipping', 'err');
          notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
          saveProgress(); moveNext();
        }
      }
    }
    chrome.downloads.onChanged.addListener(onDownloadChanged);
  });
}

function moveNext() {
  state.currentIndex++;
  // P4 FIX: Progress based on done count
  notify('HM_PROGRESS', { done: state.sessionStats.done, total: state.scripts.length, currentIdx: state.currentIndex });
  if (!state.isRunning || state.softStop || state.waitingForNet) return;
  const delay = (state.settings.delayBetween || 8) * 1000;
  addLog('⏱ Waiting ' + (delay/1000) + 's before next script...', '');
  notify('HM_STATUS', { text: 'Waiting ' + (delay/1000) + 's...', dot: 'orange' });
  saveStatus('Waiting ' + (delay/1000) + 's...', 'orange');
  setTimeout(() => { if (state.isRunning && !state.softStop) processNext(); }, delay);
}

function notify(type, data) {
  chrome.runtime.sendMessage({ type, ...data }).catch(() => {});
}
