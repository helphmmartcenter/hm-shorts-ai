// ===== HM Shorts AI - Background Service Worker =====
// Version: 1.14

// ===== KEEP-ALIVE + NET CHECK =====
chrome.alarms.create('HM_KEEPALIVE', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== 'HM_KEEPALIVE') return;
  if (state.isRunning && !state.softStop) checkNetStatus();
});

async function checkNetStatus() {
  try {
    await fetch('https://www.gstatic.com/generate_204', { method: 'HEAD', cache: 'no-store', mode: 'no-cors' });
    if (state.waitingForNet) handleNetBack();
  } catch (e) {
    if (!state.waitingForNet && state.isRunning && !state.softStop) {
      state.waitingForNet = true;
      if (netReconnectTimer) { clearTimeout(netReconnectTimer); netReconnectTimer = null; notify('HM_NET_LOST', {}); }
      addLog('⚠ Network lost — waiting for reconnect...', 'err');
      notify('HM_STATUS', { text: 'Waiting for network...', dot: 'orange' });
      saveStatus('Waiting for network...', 'orange');
    }
  }
}

// FIX 7: Network reconnect — 5 min timer
let netReconnectTimer = null;
const NET_WAIT_MS = 5 * 60 * 1000;

function handleNetBack() {
  if (!state.waitingForNet) return;
  state.waitingForNet = false;
  if (!state.isRunning || state.softStop) return;
  addLog('📶 Network restored — waiting 5 min before new scripts...', 'info');
  notify('HM_STATUS', { text: 'Network back — waiting 5 min...', dot: 'orange' });
  saveStatus('Network back — waiting 5 min...', 'orange');
  notify('HM_NET_RECONNECT_TIMER', {});
  if (netReconnectTimer) clearTimeout(netReconnectTimer);
  netReconnectTimer = setTimeout(() => {
    netReconnectTimer = null;
    if (!state.isRunning || state.softStop) return;
    addLog('✅ 5 min done — resuming scripts...', 'info');
    notify('HM_NET_TIMER_DONE', {});
    notify('HM_STATUS', { text: 'Resuming...', dot: 'green' });
    saveStatus('Running...', 'green');
    state.slots.forEach(slot => { if (slot.status === 'idle') startNextInSlot(slot); });
  }, NET_WAIT_MS);
}

// ===== MODEL URL MAP =====
const MODEL_URLS = {
  'veo3fast': 'https://geminigen.ai/veo',
  'veo3':     'https://geminigen.ai/veo',
  'veo2':     'https://geminigen.ai/veo',
  'grok3':    'https://geminigen.ai/grok',
  'sora2':    'https://geminigen.ai/sora',
  'sora2pro': 'https://geminigen.ai/sora',
};

function getModelUrl(settings) {
  const model = (settings && settings.aiModel) || 'veo3fast';
  return MODEL_URLS[model] || 'https://geminigen.ai/veo';
}

// ===== STATE =====
let state = {
  isRunning: false, softStop: false, waitingForNet: false,
  scripts: [], scriptTitles: [], settings: {},
  nextScriptIndex: 0, slots: [],
  sessionId: null, sessionStats: { done: 0, errors: [] }, sessionStartTime: null,
  // MONITOR: har slot ki history
  // tabHistory[slotIndex] = [ {time, scriptNum, title, status} ]
  tabHistory: {}
};

function initSlots(maxConcurrent) {
  state.slots = [];
  for (let i = 0; i < maxConcurrent; i++) {
    state.slots.push({
      slotIndex: i, tabId: null, scriptIndex: -1,
      status: 'idle', retries: 0, generationRetries: 0,
      waitingForSlot: false
    });
  }
}

chrome.action.onClicked.addListener(tab => { chrome.sidePanel.open({ windowId: tab.windowId }); });

function addLog(text, cls) {
  const t = new Date().toLocaleTimeString();
  const line = { t, text, cls: cls || '' };
  notify('HM_LOG', { text, cls: cls || '' });
  chrome.storage.local.get(['hmLog'], r => {
    const log = r.hmLog || [];
    log.push(line);
    if (log.length > 200) log.splice(0, log.length - 200);
    chrome.storage.local.set({ hmLog: log });
  });
}

// ===== MESSAGE HANDLER =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'HM_START') {
    state.scripts = msg.scripts;
    state.scriptTitles = msg.scriptTitles || [];
    state.settings = msg.settings;
    state.nextScriptIndex = msg.resumeIndex || 0;
    state.isRunning = true;
    state.softStop = false;
    state.waitingForNet = false;
    state.sessionId = msg.sessionId || Date.now();
    state.sessionStartTime = msg.sessionStartTime || Date.now();
    state.sessionStats = { done: msg.resumeDone || 0, errors: msg.resumeErrors || [] };
    const maxConcurrent = parseInt(state.settings.maxConcurrent) || 1;
    initSlots(maxConcurrent);
    state.tabHistory = {};
    saveProgress();
    saveButtonState('running');
    saveStatus('Opening tabs...', 'green');

    reuseExistingTabs().then(async (reusedCount) => {
      if (reusedCount > 0) {
        // Resume: already generating tabs
        addLog('📋 Resume: ' + reusedCount + ' tab(s) already generating...', 'info');
        notify('HM_RESUME_NOTIFICATION', { count: reusedCount });
        // Empty slots ko tabs do
        const modelUrl = getModelUrl(state.settings);
        for (const slot of state.slots) {
          if (!slot.tabId) {
            const tab = await chrome.tabs.create({ url: modelUrl, active: false });
            slot.tabId = tab.id;
          }
        }
        // Tabs open hone ke baad timer signal bhejo
        addLog('✅ Tabs ready — starting login check timer...', 'info');
        notify('HM_TABS_READY', { timerSeconds: parseInt(state.settings.startupTimer) || 30 });
      } else {
        // Fresh start: sab tabs kholo pehle
        const modelUrl = getModelUrl(state.settings);
        addLog('🗂 Opening ' + maxConcurrent + ' tab(s)...', 'info');
        for (const slot of state.slots) {
          const tab = await chrome.tabs.create({ url: modelUrl, active: slot.slotIndex === 0 });
          slot.tabId = tab.id;
          await sleep(300); // Stagger tab opening
        }
        // Sab tabs khul gayi — ab timer signal
        addLog('✅ All tabs open — starting login check timer...', 'info');
        notify('HM_TABS_READY', { timerSeconds: parseInt(state.settings.startupTimer) || 30 });
      }
    });
    sendResponse({ ok: true });
  }

  // Background se scripts start karo (timer complete hone ke baad sidepanel call karta hai)
  if (msg.action === 'HM_START_SCRIPTS') {
    addLog('🚀 Timer done — starting scripts...', 'info');
    saveStatus('Running...', 'green');
    state.slots.forEach(slot => {
      if (slot.tabId) startNextInSlot(slot);
    });
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_SOFT_STOP') {
    state.softStop = true;
    state.isRunning = false;
    addLog('⏸ Stopping — finishing downloads then auto-clear...', 'info');
    saveButtonState('stopped');
    saveStatus('Finishing downloads...', 'orange');
    // FIX 6: Check if any downloads in progress
    const activeDownloads = state.slots.filter(s => s.status === 'downloading' || s.status === 'generating').length;
    if (activeDownloads === 0) {
      // No active — auto clear immediately
      setTimeout(() => { clearProgress(); notify('HM_AUTO_CLEARED', {}); }, 1000);
    }
    // else: checkAllDone() will trigger auto-clear when downloads finish
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_GET_STATE') {
    sendResponse({ isRunning: state.isRunning, softStop: state.softStop, currentIndex: state.nextScriptIndex, total: state.scripts.length });
  }

  if (msg.action === 'HM_VIDEO_FOUND') {
    const tabId = sender.tab && sender.tab.id;
    // FIX 1+3: tabId se exact slot, aur sirf 'generating' status par — duplicate block
    const slot = state.slots.find(s => s.tabId === tabId && s.status === 'generating');
    if (slot) {
      // FIX 3: Immediately status change — dobara HM_VIDEO_FOUND ignore ho
      slot.status = 'downloading';
      queueDownload(slot, msg.videoUrl);
    } else {
      // Slot already downloading ya done — duplicate signal, ignore karo
      addLog('⚠ Duplicate HM_VIDEO_FOUND ignored for tab ' + tabId, 'info');
    }
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_CONTENT_ERROR') {
    const tabId = sender.tab && sender.tab.id;
    const slot = state.slots.find(s => s.tabId === tabId);
    if (slot) {
      const errMsg = msg.error || '';
      const scriptNum = slot.scriptIndex + 1;
      const skippedTitle = (state.scriptTitles && state.scriptTitles[slot.scriptIndex]) || ('Script #' + scriptNum);

      // Login required — pause everything, notify with resume info
      if (errMsg.includes('login') || errMsg.includes('sign in') || errMsg.includes('auth')) {
        addLog('🔐 Login required — pausing all slots...', 'err');
        // Put script back in queue
        state.nextScriptIndex = Math.min(state.nextScriptIndex, slot.scriptIndex);
        // Pause all slots
        state.slots.forEach(s => { s.status = 'idle'; });
        state.isRunning = false;
        state.softStop = false;
        saveButtonState('stopped');
        saveStatus('Login Required!', 'red');
        // Notify with current resume index so sidepanel can resume from same point
        notify('HM_LOGIN_REQUIRED', { resumeIndex: state.nextScriptIndex });
        sendResponse({ ok: true });
        return true;
      }

      // FIX 2: Max limit — 2 min timer, phir refresh + same script retry
      if (errMsg.includes('Maximum number') || errMsg.includes('maximum') || errMsg.includes('5 processing')) {
        addLog('⏸ Script ' + scriptNum + ': Max limit — 2 min wait phir retry...', 'info');
        slot.status = 'waiting_limit';
        notify('HM_MAX_LIMIT_TIMER', { seconds: 120 });
        setTimeout(() => {
          if (!state.isRunning || state.softStop) return;
          addLog('🔄 Script ' + scriptNum + ': Max limit wait done — refreshing tab...', 'info');
          slot.status = 'navigating';
          // Put script back
          state.nextScriptIndex = Math.min(state.nextScriptIndex, slot.scriptIndex);
          const modelUrl = getModelUrl(state.settings);
          chrome.tabs.update(slot.tabId, { url: modelUrl }, () => {
            setTimeout(() => startNextInSlot(slot), 3000);
          });
        }, 120000);
        sendResponse({ ok: true });
        return true;
      }

      // FIX 2: ALL other errors — zero retry, refresh + skip + next
      state.sessionStats.errors.push({ title: skippedTitle, error: errMsg });
      addLog('❌ Script ' + scriptNum + ': ' + errMsg + ' — skipped, refreshing tab...', 'err');
      monitorLog(slot.slotIndex, scriptNum, skippedTitle, 'skipped');
      notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
      slot.status = 'navigating';
      slot.generationRetries = 0;
      slot.retries = 0;
      // Refresh tab — page clean
      const modelUrl = getModelUrl(state.settings);
      chrome.tabs.update(slot.tabId, { url: modelUrl }, () => {
        const delay = (parseInt(state.settings.delayBetween) || 8) * 1000;
        setTimeout(() => {
          slot.status = 'idle';
          if (state.isRunning && !state.softStop) startNextInSlot(slot);
          else checkAllDone();
        }, delay);
      });
    }
    sendResponse({ ok: true });
  }

  // User ne login kar liya — tabs ko login_waiting de, refresh karo
  // Jab /veo load ho jaye tab script automatically jayegi (tabs.onUpdated mein)
  if (msg.action === 'HM_LOGIN_RETRY') {
    addLog('🔄 Login OK — refreshing tabs, scripts will resume automatically...', 'info');
    state.isRunning = true;
    state.softStop = false;
    saveButtonState('running');
    saveStatus('Checking login...', 'green');
    const modelUrl = getModelUrl(state.settings);
    state.slots.forEach(slot => {
      if (slot.tabId) {
        slot.status = 'login_waiting';
        // Refresh tab — tabs.onUpdated will detect /veo and resume script
        chrome.tabs.update(slot.tabId, { url: modelUrl });
      } else {
        // No tab — open new one
        slot.status = 'idle';
        startNextInSlot(slot);
      }
    });
    sendResponse({ ok: true });
  }

  // FIX: Open tabs only — timer ke liye pehle tabs kholo
  if (msg.action === 'HM_OPEN_TABS_ONLY') {
    const settings = msg.settings || {};
    const maxConcurrent = parseInt(settings.maxConcurrent) || 1;
    const modelUrl = MODEL_URLS[(settings.aiModel) || 'veo3fast'] || 'https://geminigen.ai/veo';
    initSlots(maxConcurrent);
    state.tabHistory = {};
    state.settings = settings;
    let opened = 0;
    // Open tabs without starting scripts
    async function openTabs() {
      // Reuse existing tabs first
      const existing = await chrome.tabs.query({ url: 'https://geminigen.ai/*' });
      for (let i = 0; i < Math.min(existing.length, maxConcurrent); i++) {
        state.slots[i].tabId = existing[i].id;
        opened++;
      }
      // Open remaining tabs
      for (let i = opened; i < maxConcurrent; i++) {
        const tab = await chrome.tabs.create({ url: modelUrl, active: i === 0 });
        state.slots[i].tabId = tab.id;
        await new Promise(r => setTimeout(r, 500));
      }
      addLog('✅ ' + maxConcurrent + ' tab(s) opened — timer start hoga...', 'info');
    }
    openTabs().then(() => sendResponse({ ok: true, count: maxConcurrent }));
    return true;
  }

  if (msg.action === 'HM_GET_MONITOR') {
    sendResponse({ tabHistory: state.tabHistory });
    return true;
  }

  if (msg.action === 'HM_GET_PROGRESS') {
    chrome.storage.local.get(['hmProgress'], r => { sendResponse({ progress: r.hmProgress || null }); });
    return true;
  }

  if (msg.action === 'HM_GET_HISTORY') {
    chrome.storage.local.get(['hmHistory'], r => { sendResponse({ history: r.hmHistory || [] }); });
    return true;
  }

  if (msg.action === 'HM_CLEAR_HISTORY') {
    chrome.storage.local.remove(['hmHistory'], () => sendResponse({ ok: true }));
    return true;
  }

  return true;
});

// ===== P3 FIX: Reuse existing GeminiGen tabs =====
async function reuseExistingTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://geminigen.ai/*' });
    const maxConcurrent = state.slots.length;
    let reused = 0;
    for (let i = 0; i < Math.min(tabs.length, maxConcurrent); i++) {
      state.slots[i].tabId = tabs[i].id;
      // Mark as generating if tab has generation_uuid in URL
      if (tabs[i].url && tabs[i].url.includes('generation_uuid')) {
        state.slots[i].status = 'generating';
        state.slots[i].generatingStartTime = Date.now();
      }
      reused++;
    }
    return reused;
  } catch(e) { return 0; }
}

// ===== WATCHDOG — Stuck slot detect karo =====
// Har 2 minute check karo — 8+ minute se generating mein stuck hai?
// FIX 3: Generation Timeout — user settable (default 5 min)
// Settings mein 'generationTimeout' minutes set kar sakte hain
setInterval(() => {
  if (!state.isRunning || state.softStop) return;
  const now = Date.now();
  const timeoutMin = parseInt(state.settings.generationTimeout) || 5;
  const timeoutMs  = timeoutMin * 60 * 1000;
  state.slots.forEach(slot => {
    if (slot.status === 'generating' && slot.generatingStartTime) {
      const elapsed = now - slot.generatingStartTime;
      if (elapsed > timeoutMs) {
        const title = (state.scriptTitles && state.scriptTitles[slot.scriptIndex]) || ('Script #' + (slot.scriptIndex+1));
        addLog('⚠ Script ' + (slot.scriptIndex+1) + ' stuck ' + timeoutMin + 'min — refreshing tab, skip...', 'err');
        state.sessionStats.errors.push({ title, error: 'Stuck — skipped after ' + timeoutMin + ' min timeout' });
        notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
        slot.status = 'navigating';
        slot.generationRetries = 0;
        slot.generatingStartTime = null;
        // FIX: Refresh tab — page clean
        const modelUrl = getModelUrl(state.settings);
        chrome.tabs.update(slot.tabId, { url: modelUrl }, () => {
          const delay = (parseInt(state.settings.delayBetween) || 8) * 1000;
          setTimeout(() => {
            slot.status = 'idle';
            if (state.isRunning && !state.softStop) startNextInSlot(slot);
            else checkAllDone();
          }, delay);
        });
      }
    }
  });
}, 60 * 1000); // Every 1 minute check

function saveButtonState(s) { chrome.storage.local.set({ hmButtonState: s }); }
function saveStatus(text, dot) { chrome.storage.local.set({ hmStatus: { text, dot } }); }

function saveProgress() {
  chrome.storage.local.set({ hmProgress: {
    currentIndex: state.nextScriptIndex, total: state.scripts.length,
    scripts: state.scripts, scriptTitles: state.scriptTitles, settings: state.settings,
    sessionId: state.sessionId, sessionStartTime: state.sessionStartTime,
    sessionStats: state.sessionStats, savedAt: Date.now()
  }});
}

function clearProgress() { chrome.storage.local.remove(['hmProgress', 'hmLog', 'hmStatus', 'hmButtonState']); }

function saveSessionToHistory(status, totalTime) {
  if (!state.sessionId) return;
  const session = {
    id: state.sessionId, date: new Date().toLocaleDateString(), time: new Date().toLocaleTimeString(),
    total: state.scripts.length, done: state.sessionStats.done, errors: state.sessionStats.errors,
    status, totalTime: totalTime || 0
  };
  chrome.storage.local.get(['hmHistory'], r => {
    const history = r.hmHistory || [];
    history.unshift(session);
    if (history.length > 30) history.splice(30);
    chrome.storage.local.set({ hmHistory: history });
    notify('HM_HISTORY_UPDATED', {});
  });
}

// ===== SLIDING WINDOW CORE =====
async function startNextInSlot(slot) {
  if (slot.status !== 'idle') return;
  if (!state.isRunning || state.softStop || state.waitingForNet) return;
  if (state.nextScriptIndex >= state.scripts.length) { checkAllDone(); return; }

  const scriptIdx = state.nextScriptIndex++;
  slot.scriptIndex = scriptIdx;
  slot.status = 'navigating';
  slot.generationRetries = 0;

  const script = state.scripts[scriptIdx];
  const total = state.scripts.length;
  const maxConcurrent = state.slots.length;
  const modelUrl = getModelUrl(state.settings);

  addLog('▶ Script ' + (scriptIdx+1) + '/' + total + (maxConcurrent > 1 ? ' [Slot ' + (slot.slotIndex+1) + ']' : '') + ': ' + script.substring(0,35) + '...', 'info');
  // Monitor entry tab add hogi jab generating shuru ho (slot.status = generating set hone par)
  notify('HM_PROGRESS', { done: state.sessionStats.done, total, currentIdx: state.nextScriptIndex });
  notify('HM_STATUS', { text: 'Active: ' + state.slots.filter(s=>s.status!=='idle'&&s.status!=='waiting_limit').length + '/' + maxConcurrent + ' | Done: ' + state.sessionStats.done, dot: 'green' });
  saveProgress();

  try {
    if (slot.tabId) {
      try {
        const tab = await chrome.tabs.get(slot.tabId);
        const url = tab.url || '';
        // P2 FIX: Check if already on correct model URL without uuid
        const modelPath = new URL(modelUrl).pathname;
        if (url.includes(modelPath) && !url.includes('generation_uuid') && !url.includes('auth/login')) {
          await sleep(500);
        } else {
          await chrome.tabs.update(slot.tabId, { url: modelUrl });
          await waitForTabLoad(slot.tabId);
          await sleep(2000);
        }
      } catch(e) { slot.tabId = null; }
    }

    if (!slot.tabId) {
      const newTab = await chrome.tabs.create({ url: modelUrl, active: slot.slotIndex === 0 });
      slot.tabId = newTab.id;
      await waitForTabLoad(slot.tabId);
      await sleep(2500);
    }

    // P7 FIX: Check if login page
    try {
      const tab = await chrome.tabs.get(slot.tabId);
      if (tab.url && (tab.url.includes('auth/login') || tab.url.includes('auth/signin'))) {
        addLog('🔐 Tab ' + (slot.slotIndex+1) + ': Login page detected — pausing all...', 'err');
        // Put script back
        state.nextScriptIndex = Math.min(state.nextScriptIndex, scriptIdx);
        // Pause all slots
        state.slots.forEach(s => { s.status = 'idle'; });
        state.isRunning = false;
        state.softStop = false;
        saveButtonState('stopped');
        saveStatus('Login Required!', 'red');
        notify('HM_LOGIN_REQUIRED', { resumeIndex: state.nextScriptIndex });
        return;
      }
    } catch(e) {}

    slot.status = 'generating';
    slot.generatingStartTime = Date.now();
    // FIX 3: Monitor entry sirf tab jab generating actually shuru ho
    monitorLog(slot.slotIndex, scriptIdx+1, state.scriptTitles[scriptIdx] || ('Script #'+(scriptIdx+1)), 'generating');
    await runAutomationInSlot(slot, script);

  } catch(e) {
    addLog('❌ Script ' + (scriptIdx+1) + ' error: ' + e.message, 'err');
    slot.status = 'idle';
    if (state.isRunning && !state.softStop) setTimeout(() => startNextInSlot(slot), 5000);
    else checkAllDone();
  }
}

function checkAllDone() {
  const allIdle = state.slots.every(s => s.status === 'idle' || s.status === 'waiting_limit');
  const noMore = state.nextScriptIndex >= state.scripts.length;
  if (!allIdle || !noMore) return;

  if (state.softStop) {
    // FIX 6: Stop ke baad downloads complete — auto clear
    const totalTime = state.sessionStartTime ? Math.round((Date.now() - state.sessionStartTime) / 1000) : 0;
    saveSessionToHistory('stopped', totalTime);
    clearProgress();
    saveButtonState('done');
    saveStatus('Stopped & Cleared ✓', 'green');
    notify('HM_AUTO_CLEARED', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
    return;
  }

  state.isRunning = false;
  const totalTime = state.sessionStartTime ? Math.round((Date.now() - state.sessionStartTime) / 1000) : 0;
  saveSessionToHistory('done', totalTime);
  clearProgress();
  saveButtonState('done');
  saveStatus('All Done! ✓', 'green');
  notify('HM_DONE', { total: state.scripts.length, done: state.sessionStats.done, errors: state.sessionStats.errors.length, totalTime });
}

function waitForTabLoad(tabId) {
  return new Promise(resolve => {
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(listener); resolve(); }
    }
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(resolve, 15000);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

// FIX 2: Textarea appear hone ka wait karo — page properly ready
async function waitForPageReady(tabId) {
  const maxTries = 30; // 15 sec max (30 x 500ms)
  for (let i = 0; i < maxTries; i++) {
    try {
      const results = await chrome.scripting.executeScript({
        target: { tabId },
        func: () => {
          // Check textarea ya contenteditable ready hai
          const selectors = [
            'textarea[placeholder*="Describe"]', 'textarea[placeholder*="describe"]',
            'textarea[placeholder*="video"]', 'textarea[placeholder*="generate"]',
            'textarea[placeholder*="Generate"]', 'textarea',
            '[contenteditable="true"]'
          ];
          for (const sel of selectors) {
            const el = document.querySelector(sel);
            if (el) return true;
          }
          return false;
        }
      });
      if (results && results[0] && results[0].result === true) {
        return true; // Page ready!
      }
    } catch(e) { /* tab abhi load ho raha hai */ }
    await sleep(500);
  }
  return false; // Timeout — try anyway
}

async function runAutomationInSlot(slot, scriptText) {
  try {
    // FIX 2: Pehle page ready hone ka wait karo
    addLog('⏳ Tab ' + (slot.slotIndex+1) + ' — page ready ka wait...', 'info');
    const ready = await waitForPageReady(slot.tabId);
    if (!ready) {
      addLog('⚠ Tab ' + (slot.slotIndex+1) + ' — page ready nahi, phir bhi try kar raha...', 'info');
    }
    await sleep(500); // Extra small buffer
    await chrome.scripting.executeScript({ target: { tabId: slot.tabId }, func: automationScript, args: [scriptText, state.settings] });
    addLog('⏳ Script ' + (slot.scriptIndex+1) + ' — Waiting for video...', 'info');
  } catch(e) {
    addLog('❌ Script ' + (slot.scriptIndex+1) + ' injection failed: ' + e.message, 'err');
    slot.status = 'idle';
    if (state.isRunning && !state.softStop) setTimeout(() => startNextInSlot(slot), 5000);
    else checkAllDone();
  }
}

function automationScript(scriptText, settings) {
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  async function run() {
    try {
      // P1 FIX: Check for generation failed / max limit errors first
      const bodyText = document.body.innerText || '';
      if (bodyText.includes('Maximum number of processing') || bodyText.includes('maximum') && bodyText.includes('processing')) {
        chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Maximum number of processing generations reached' });
        return;
      }
      if (bodyText.includes('Generation failed') || bodyText.includes('Media not found')) {
        chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation failed — Media not found' });
        return;
      }

      let textarea = null;
      const textareaSelectors = ['textarea[placeholder*="Describe"]','textarea[placeholder*="describe"]','textarea[placeholder*="video"]','textarea[placeholder*="generate"]','textarea[placeholder*="Generate"]','textarea'];
      for (const sel of textareaSelectors) { textarea = document.querySelector(sel); if (textarea) break; }
      if (!textarea) textarea = document.querySelector('[contenteditable="true"]');
      if (!textarea) { chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Input field not found' }); return; }

      textarea.focus(); await sleep(300);
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
      if (nativeSetter && nativeSetter.set) { nativeSetter.set.call(textarea, ''); } else { textarea.value = ''; }
      textarea.dispatchEvent(new Event('input', { bubbles: true })); await sleep(200);
      if (nativeSetter && nativeSetter.set) { nativeSetter.set.call(textarea, scriptText); } else { textarea.value = scriptText; }
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      textarea.dispatchEvent(new Event('change', { bubbles: true })); await sleep(500);

      const btnSelectors = ['button[type="submit"]','button[aria-label*="enerate"]','button[aria-label*="send"]','button[aria-label*="Send"]','button[title*="enerate"]','button[class*="send"]','button[class*="submit"]','button[class*="generate"]','form button:last-child','button svg'];
      let genBtn = null;
      for (const sel of btnSelectors) { const el = document.querySelector(sel); if (el) { genBtn = el.closest('button') || el; break; } }
      if (genBtn) { genBtn.click(); await sleep(500); }
      else { textarea.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, ctrlKey: false, bubbles: true })); await sleep(500); }

      const oldUrl = window.location.href;
      let urlPollCount = 0;
      const urlPollInterval = setInterval(() => {
        urlPollCount++;
        if (urlPollCount > 60) { clearInterval(urlPollInterval); chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation did not start (60s timeout)' }); return; }

        // P1 FIX: Check for errors during polling
        const bodyNow = document.body.innerText || '';
        if (bodyNow.includes('Maximum number of processing')) {
          clearInterval(urlPollInterval);
          chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Maximum number of processing generations reached' });
          return;
        }
        if (bodyNow.includes('Generation failed') || bodyNow.includes('Media not found')) {
          clearInterval(urlPollInterval);
          chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation failed — Media not found' });
          return;
        }

        const currentUrl = window.location.href;
        if ((currentUrl !== oldUrl) && currentUrl.includes('generation_uuid')) {
          clearInterval(urlPollInterval);
          let pollCount = 0;
          const pollInterval = setInterval(async () => {
            pollCount++;
            if (pollCount > 150) { clearInterval(pollInterval); chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Video generation timeout (7.5 min)' }); return; }

            const bt = document.body.innerText || '';
            // P1 FIX: Detect generation failed inside generation page
            if (bt.includes('Generation failed') || bt.includes('Media not found') || bt.includes('try again later')) {
              clearInterval(pollInterval);
              chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation failed — Media not found' });
              return;
            }
            if (bt.includes('Maximum number of processing')) {
              clearInterval(pollInterval);
              chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Maximum number of processing generations reached' });
              return;
            }

            if (bt.includes('being created') || bt.includes('AI magic') || bt.includes('being generated')) return;
            const downloadSelectors = ['a[download]','button[aria-label*="ownload"]','button[title*="ownload"]','button[class*="download"]','[data-action*="download"]'];
            let downloadEl = null;
            for (const sel of downloadSelectors) { downloadEl = document.querySelector(sel); if (downloadEl) break; }
            const videoEl = document.querySelector('video[src]:not([src=""])');
            if (downloadEl || videoEl) {
              clearInterval(pollInterval);
              let videoUrl = null;
              const pageTitle = document.title || 'video';
              if (downloadEl) { if (downloadEl.tagName === 'A' && downloadEl.href) videoUrl = downloadEl.href; await sleep(300); downloadEl.click(); await sleep(1000); }
              if (!videoUrl && videoEl) videoUrl = videoEl.src;
              if (!videoUrl) { const allVideos = document.querySelectorAll('video'); for (const v of allVideos) { if (v.src && v.src !== '') { videoUrl = v.src; break; } } }
              chrome.runtime.sendMessage({ action: 'HM_VIDEO_FOUND', videoUrl, tabTitle: pageTitle });
              clearInterval(pollInterval); // FIX 3: Dobara fire mat karo
            }
          }, 3000);
        }
      }, 1000);
    } catch (err) { chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: err.message }); }
  }
  run();
}

// FIX 4: Download Queue — baari baari download, ek saath nahi
let downloadQueue = [];
let downloadInProgress = false;

function queueDownload(slot, videoUrl) {
  downloadQueue.push({ slot, videoUrl });
  processDownloadQueue();
}

function processDownloadQueue() {
  if (downloadInProgress || downloadQueue.length === 0) return;
  downloadInProgress = true;
  const { slot, videoUrl } = downloadQueue.shift();
  handleVideoFoundInSlot(slot, videoUrl);
}

function handleVideoFoundInSlot(slot, videoUrl) {
  const folder = state.settings.folderName || 'HM_Shorts_AI_Videos';
  // FIX 2: Title — slot.scriptIndex se, fallback Script_N (never timestamp)
  const rawTitle = (state.scriptTitles && state.scriptTitles[slot.scriptIndex]) || '';
  const safeTitle = rawTitle.trim().replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, '_').substring(0, 80);
  // Use script number as fallback — never use timestamp filename
  const finalTitle = safeTitle || ('Script_' + (slot.scriptIndex + 1));
  const filename = folder + '/' + finalTitle + '.mp4';
  addLog('⬇ Downloading Script #' + (slot.scriptIndex+1), 'dl');
  monitorLog(slot.slotIndex, slot.scriptIndex+1, rawTitle || ('Script #'+(slot.scriptIndex+1)), 'downloading');

  if (!videoUrl) {
    state.sessionStats.errors.push({ title: rawTitle || ('Script #' + (slot.scriptIndex+1)), error: 'Video URL not found' });
    addLog('⚠ No video URL — skipping Script #' + (slot.scriptIndex+1), 'err');
    notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
    slot.status = 'idle';
    // P2 FIX: Move tab to /veo before next script
    moveTabToModel(slot);
    if (state.isRunning && !state.softStop) startNextInSlot(slot); else checkAllDone();
    return;
  }

  chrome.downloads.download({ url: videoUrl, filename, saveAs: false }, downloadId => {
    if (chrome.runtime.lastError || !downloadId) {
      // FIX 2+4: Download fail — zero retry, refresh + skip
      addLog('❌ Download failed — Script #' + (slot.scriptIndex+1) + ' skipped, refreshing...', 'err');
      state.sessionStats.errors.push({ title: rawTitle || ('Script #' + (slot.scriptIndex+1)), error: 'Download failed' });
      notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
      slot.status = 'navigating'; slot.retries = 0;
      downloadInProgress = false; processDownloadQueue();
      const modelUrlF = getModelUrl(state.settings);
      chrome.tabs.update(slot.tabId, { url: modelUrlF }, () => {
        const delay = (parseInt(state.settings.delayBetween) || 8) * 1000;
        setTimeout(() => { slot.status = 'idle'; if (state.isRunning && !state.softStop) startNextInSlot(slot); else checkAllDone(); }, delay);
      });
      return;
    }

    addLog('📥 Script #' + (slot.scriptIndex+1) + ' → ' + finalTitle + ' downloading...', 'dl');
    function onDownloadChanged(delta) {
      if (delta.id !== downloadId) return;
      if (delta.state && delta.state.current === 'complete') {
        chrome.downloads.onChanged.removeListener(onDownloadChanged);
        state.sessionStats.done++;
        addLog('✅ Script #' + (slot.scriptIndex+1) + ' → ' + finalTitle + ' done!', 'ok');
        monitorLog(slot.slotIndex, slot.scriptIndex+1, finalTitle, 'done');
        notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
        notify('HM_PROGRESS', { done: state.sessionStats.done, total: state.scripts.length, currentIdx: state.nextScriptIndex });
        saveProgress();
        slot.status = 'idle'; slot.retries = 0; slot.generatingStartTime = null;
        // FIX 4: Queue — next download shuru karo
        downloadInProgress = false; processDownloadQueue();
        // Release waiting_limit slots
        state.slots.forEach(s => { if (s.status === 'waiting_limit') { s.status = 'idle'; if (state.isRunning && !state.softStop) startNextInSlot(s); } });
        // Tab refresh — page clean
        const modelUrlC = getModelUrl(state.settings);
        chrome.tabs.update(slot.tabId, { url: modelUrlC }, () => {
          const delay = (parseInt(state.settings.delayBetween) || 8) * 1000;
          setTimeout(() => { if (state.isRunning && !state.softStop) startNextInSlot(slot); else checkAllDone(); }, delay);
        });
      }
      if (delta.state && delta.state.current === 'interrupted') {
        chrome.downloads.onChanged.removeListener(onDownloadChanged);
        // FIX 2+4: Interrupted — zero retry, skip
        addLog('❌ Download interrupted — Script #' + (slot.scriptIndex+1) + ' skipped, refreshing...', 'err');
        state.sessionStats.errors.push({ title: rawTitle || ('Script #' + (slot.scriptIndex+1)), error: 'Download interrupted' });
        notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
        slot.status = 'navigating'; slot.retries = 0;
        downloadInProgress = false; processDownloadQueue();
        const modelUrlI = getModelUrl(state.settings);
        chrome.tabs.update(slot.tabId, { url: modelUrlI }, () => {
          const delay = (parseInt(state.settings.delayBetween) || 8) * 1000;
          setTimeout(() => { slot.status = 'idle'; if (state.isRunning && !state.softStop) startNextInSlot(slot); else checkAllDone(); }, delay);
        });
      }
    }
    chrome.downloads.onChanged.addListener(onDownloadChanged);
  });
}

// P2 FIX: Move tab back to model URL after download
function moveTabToModel(slot) {
  if (!slot.tabId) return;
  const modelUrl = getModelUrl(state.settings);
  chrome.tabs.get(slot.tabId, tab => {
    if (chrome.runtime.lastError) return;
    if (tab && tab.url && !tab.url.includes(new URL(modelUrl).pathname.split('?')[0])) {
      chrome.tabs.update(slot.tabId, { url: modelUrl });
    }
  });
}

function notify(type, data) { chrome.runtime.sendMessage({ type, ...data }).catch(() => {}); }

// ===== LOGIN DETECT via URL change =====
chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (!state.isRunning || state.softStop) return;
  if (changeInfo.status !== 'loading' && changeInfo.status !== 'complete') return;
  const url = tab.url || changeInfo.url || '';
  if (!url) return;

  // Check if this tab belongs to any slot
  const slot = state.slots.find(s => s.tabId === tabId);
  if (!slot) return;

  // Login page detect
  if (url.includes('auth/login') || url.includes('auth/signin')) {
    addLog('🔐 Tab ' + (slot.slotIndex+1) + ': Login page — pausing...', 'err');
    // Pause this slot — script index back
    state.nextScriptIndex = Math.min(state.nextScriptIndex, slot.scriptIndex);
    slot.status = 'idle';
    // Pause all running
    state.isRunning = false;
    saveButtonState('stopped');
    saveStatus('Login Required!', 'red');
    notify('HM_LOGIN_REQUIRED', { resumeIndex: state.nextScriptIndex });
    return;
  }

  // Page ready after login OK — /veo ya model URL aa gaya
  if (slot.status === 'login_waiting' && changeInfo.status === 'complete') {
    const modelUrl = getModelUrl(state.settings);
    const modelPath = new URL(modelUrl).pathname;
    if (url.includes(modelPath) && !url.includes('auth/')) {
      addLog('✅ Tab ' + (slot.slotIndex+1) + ': Login confirmed — submitting script...', 'info');
      slot.status = 'idle';
      if (state.isRunning && !state.softStop) startNextInSlot(slot);
    }
  }
});

// ===== MONITOR HELPER =====
function monitorLog(slotIndex, scriptNum, title, status) {
  const t = new Date().toLocaleTimeString();
  if (!state.tabHistory[slotIndex]) state.tabHistory[slotIndex] = [];
  state.tabHistory[slotIndex].push({ time: t, scriptNum, title, status });
  // Keep last 50 entries per slot
  if (state.tabHistory[slotIndex].length > 50) {
    state.tabHistory[slotIndex].splice(0, state.tabHistory[slotIndex].length - 50);
  }
  notify('HM_MONITOR_UPDATE', { tabHistory: state.tabHistory });
}
