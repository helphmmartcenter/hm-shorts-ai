// HM Shorts AI - Content Script
// Version: 1.12
// Runs on geminigen.ai pages
console.log('[HM Shorts AI] Content script active on', location.href);
