// ===== HM Shorts AI - Background Service Worker =====
// Version: 1.14

// ===== KEEP-ALIVE + NET CHECK =====
chrome.alarms.create('HM_KEEPALIVE', { periodInMinutes: 0.4 });
chrome.alarms.onAlarm.addListener(alarm => {
  if (alarm.name !== 'HM_KEEPALIVE') return;
  if (state.isRunning && !state.softStop) checkNetStatus();
});

async function checkNetStatus() {
  try {
    await fetch('https://www.gstatic.com/generate_204', { method: 'HEAD', cache: 'no-store', mode: 'no-cors' });
    if (state.waitingForNet) handleNetBack();
  } catch (e) {
    if (!state.waitingForNet && state.isRunning && !state.softStop) {
      state.waitingForNet = true;
      addLog('⚠ Network lost — waiting for reconnect...', 'err');
      notify('HM_STATUS', { text: 'Waiting for network...', dot: 'orange' });
      saveStatus('Waiting for network...', 'orange');
    }
  }
}

function handleNetBack() {
  if (!state.waitingForNet) return;
  state.waitingForNet = false;
  if (!state.isRunning || state.softStop) return;
  addLog('📶 Network restored — resuming...', 'info');
  notify('HM_STATUS', { text: 'Network restored — continuing...', dot: 'green' });
  state.slots.forEach(slot => { if (slot.status === 'idle') startNextInSlot(slot); });
}

// ===== MODEL URL MAP =====
const MODEL_URLS = {
  'veo3fast': 'https://geminigen.ai/veo',
  'veo3':     'https://geminigen.ai/veo',
  'veo2':     'https://geminigen.ai/veo',
  'grok3':    'https://geminigen.ai/grok',
  'sora2':    'https://geminigen.ai/sora',
  'sora2pro': 'https://geminigen.ai/sora',
};

function getModelUrl(settings) {
  const model = (settings && settings.aiModel) || 'veo3fast';
  return MODEL_URLS[model] || 'https://geminigen.ai/veo';
}

// ===== STATE =====
let state = {
  isRunning: false, softStop: false, waitingForNet: false,
  scripts: [], scriptTitles: [], settings: {},
  nextScriptIndex: 0, slots: [],
  sessionId: null, sessionStats: { done: 0, errors: [] }, sessionStartTime: null
};

function initSlots(maxConcurrent) {
  state.slots = [];
  for (let i = 0; i < maxConcurrent; i++) {
    state.slots.push({
      slotIndex: i, tabId: null, scriptIndex: -1,
      status: 'idle', retries: 0, generationRetries: 0,
      waitingForSlot: false
    });
  }
}

chrome.action.onClicked.addListener(tab => { chrome.sidePanel.open({ windowId: tab.windowId }); });

function addLog(text, cls) {
  const t = new Date().toLocaleTimeString();
  const line = { t, text, cls: cls || '' };
  notify('HM_LOG', { text, cls: cls || '' });
  chrome.storage.local.get(['hmLog'], r => {
    const log = r.hmLog || [];
    log.push(line);
    if (log.length > 200) log.splice(0, log.length - 200);
    chrome.storage.local.set({ hmLog: log });
  });
}

// ===== MESSAGE HANDLER =====
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {

  if (msg.action === 'HM_START') {
    state.scripts = msg.scripts;
    state.scriptTitles = msg.scriptTitles || [];
    state.settings = msg.settings;
    state.nextScriptIndex = msg.resumeIndex || 0;
    state.isRunning = true;
    state.softStop = false;
    state.waitingForNet = false;
    state.sessionId = msg.sessionId || Date.now();
    state.sessionStartTime = msg.sessionStartTime || Date.now();
    state.sessionStats = { done: msg.resumeDone || 0, errors: msg.resumeErrors || [] };
    const maxConcurrent = parseInt(state.settings.maxConcurrent) || 1;
    initSlots(maxConcurrent);
    saveProgress();
    saveButtonState('running');
    saveStatus('Running...', 'green');
    // P3 FIX: Reuse existing GeminiGen tabs on start/resume
    reuseExistingTabs().then(() => {
      state.slots.forEach(slot => startNextInSlot(slot));
    });
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_SOFT_STOP') {
    state.softStop = true;
    state.isRunning = false;
    addLog('⏸ Stopping — waiting for active tasks to complete...', 'info');
    saveButtonState('stopped');
    saveStatus('Stopping...', 'orange');
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_GET_STATE') {
    sendResponse({ isRunning: state.isRunning, softStop: state.softStop, currentIndex: state.nextScriptIndex, total: state.scripts.length });
  }

  if (msg.action === 'HM_VIDEO_FOUND') {
    const tabId = sender.tab && sender.tab.id;
    const slot = state.slots.find(s => s.tabId === tabId && s.status === 'generating');
    if (slot) { slot.status = 'downloading'; handleVideoFoundInSlot(slot, msg.videoUrl, msg.tabTitle); }
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_CONTENT_ERROR') {
    const tabId = sender.tab && sender.tab.id;
    const slot = state.slots.find(s => s.tabId === tabId);
    if (slot) {
      const errMsg = msg.error || '';
      const scriptNum = slot.scriptIndex + 1;

      // P4 FIX: Max limit error — wait for a slot to free up
      if (errMsg.includes('Maximum number') || errMsg.includes('maximum') || errMsg.includes('5 processing')) {
        addLog('⏸ Script ' + scriptNum + ': Max limit reached — waiting for slot...', 'info');
        slot.status = 'waiting_limit';
        // Put script back in queue
        state.nextScriptIndex = Math.min(state.nextScriptIndex, slot.scriptIndex);
        // Retry after 30 seconds
        setTimeout(() => {
          if (state.isRunning && !state.softStop) {
            slot.status = 'idle';
            startNextInSlot(slot);
          }
        }, 30000);
        sendResponse({ ok: true });
        return true;
      }

      // P1+P5 FIX: Generation failed — retry once
      if (errMsg.includes('Generation failed') || errMsg.includes('Media not found') ||
          errMsg.includes('try again') || errMsg.includes('failed')) {
        if (slot.generationRetries < 1) {
          slot.generationRetries++;
          addLog('⚠ Script ' + scriptNum + ': Generation failed — retrying (' + slot.generationRetries + '/1)...', 'info');
          slot.status = 'idle';
          // Put script back
          state.nextScriptIndex = Math.min(state.nextScriptIndex, slot.scriptIndex);
          setTimeout(() => startNextInSlot(slot), 5000);
          sendResponse({ ok: true });
          return true;
        }
      }

      // P7 FIX: Login required
      if (errMsg.includes('login') || errMsg.includes('sign in') || errMsg.includes('auth')) {
        addLog('🔐 Script ' + scriptNum + ': Login required — please login to GeminiGen', 'err');
        notify('HM_LOGIN_REQUIRED', {});
        slot.status = 'idle';
        state.nextScriptIndex = Math.min(state.nextScriptIndex, slot.scriptIndex);
        sendResponse({ ok: true });
        return true;
      }

      // Normal error — skip
      const skippedTitle = (state.scriptTitles && state.scriptTitles[slot.scriptIndex]) || ('Script #' + scriptNum);
      state.sessionStats.errors.push({ title: skippedTitle, error: errMsg });
      addLog('❌ Script ' + scriptNum + ': ' + errMsg, 'err');
      notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
      slot.status = 'idle';
      slot.generationRetries = 0;
      if (state.isRunning && !state.softStop) { setTimeout(() => startNextInSlot(slot), 3000); }
      else checkAllDone();
    }
    sendResponse({ ok: true });
  }

  if (msg.action === 'HM_GET_PROGRESS') {
    chrome.storage.local.get(['hmProgress'], r => { sendResponse({ progress: r.hmProgress || null }); });
    return true;
  }

  if (msg.action === 'HM_GET_HISTORY') {
    chrome.storage.local.get(['hmHistory'], r => { sendResponse({ history: r.hmHistory || [] }); });
    return true;
  }

  if (msg.action === 'HM_CLEAR_HISTORY') {
    chrome.storage.local.remove(['hmHistory'], () => sendResponse({ ok: true }));
    return true;
  }

  return true;
});

// ===== P3 FIX: Reuse existing GeminiGen tabs =====
async function reuseExistingTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: 'https://geminigen.ai/*' });
    const maxConcurrent = state.slots.length;
    for (let i = 0; i < Math.min(tabs.length, maxConcurrent); i++) {
      state.slots[i].tabId = tabs[i].id;
    }
  } catch(e) {}
}

// ===== WATCHDOG — Stuck slot detect karo =====
// Har 2 minute check karo — 8+ minute se generating mein stuck hai?
setInterval(() => {
  if (!state.isRunning || state.softStop) return;
  const now = Date.now();
  state.slots.forEach(slot => {
    if (slot.status === 'generating' && slot.generatingStartTime) {
      const elapsed = now - slot.generatingStartTime;
      if (elapsed > 8 * 60 * 1000) { // 8 minutes
        addLog('⚠ Script ' + (slot.scriptIndex+1) + ' stuck 8min — force skip', 'err');
        const title = (state.scriptTitles && state.scriptTitles[slot.scriptIndex]) || ('Script #' + (slot.scriptIndex+1));
        state.sessionStats.errors.push({ title, error: 'Stuck — force skipped after 8 min' });
        notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
        slot.status = 'idle';
        slot.generationRetries = 0;
        slot.generatingStartTime = null;
        moveTabToModel(slot);
        if (state.isRunning && !state.softStop) startNextInSlot(slot);
        else checkAllDone();
      }
    }
  });
}, 2 * 60 * 1000); // Every 2 minutes

function saveButtonState(s) { chrome.storage.local.set({ hmButtonState: s }); }
function saveStatus(text, dot) { chrome.storage.local.set({ hmStatus: { text, dot } }); }

function saveProgress() {
  chrome.storage.local.set({ hmProgress: {
    currentIndex: state.nextScriptIndex, total: state.scripts.length,
    scripts: state.scripts, scriptTitles: state.scriptTitles, settings: state.settings,
    sessionId: state.sessionId, sessionStartTime: state.sessionStartTime,
    sessionStats: state.sessionStats, savedAt: Date.now()
  }});
}

function clearProgress() { chrome.storage.local.remove(['hmProgress', 'hmLog', 'hmStatus', 'hmButtonState']); }

function saveSessionToHistory(status, totalTime) {
  if (!state.sessionId) return;
  const session = {
    id: state.sessionId, date: new Date().toLocaleDateString(), time: new Date().toLocaleTimeString(),
    total: state.scripts.length, done: state.sessionStats.done, errors: state.sessionStats.errors,
    status, totalTime: totalTime || 0
  };
  chrome.storage.local.get(['hmHistory'], r => {
    const history = r.hmHistory || [];
    history.unshift(session);
    if (history.length > 30) history.splice(30);
    chrome.storage.local.set({ hmHistory: history });
    notify('HM_HISTORY_UPDATED', {});
  });
}

// ===== SLIDING WINDOW CORE =====
async function startNextInSlot(slot) {
  if (slot.status !== 'idle') return;
  if (!state.isRunning || state.softStop || state.waitingForNet) return;
  if (state.nextScriptIndex >= state.scripts.length) { checkAllDone(); return; }

  const scriptIdx = state.nextScriptIndex++;
  slot.scriptIndex = scriptIdx;
  slot.status = 'navigating';
  slot.generationRetries = 0;

  const script = state.scripts[scriptIdx];
  const total = state.scripts.length;
  const maxConcurrent = state.slots.length;
  const modelUrl = getModelUrl(state.settings);

  addLog('▶ Script ' + (scriptIdx+1) + '/' + total + (maxConcurrent > 1 ? ' [Slot ' + (slot.slotIndex+1) + ']' : '') + ': ' + script.substring(0,35) + '...', 'info');
  notify('HM_PROGRESS', { done: state.sessionStats.done, total, currentIdx: state.nextScriptIndex });
  notify('HM_STATUS', { text: 'Active: ' + state.slots.filter(s=>s.status!=='idle'&&s.status!=='waiting_limit').length + '/' + maxConcurrent + ' | Done: ' + state.sessionStats.done, dot: 'green' });
  saveProgress();

  try {
    if (slot.tabId) {
      try {
        const tab = await chrome.tabs.get(slot.tabId);
        const url = tab.url || '';
        // P2 FIX: Check if already on correct model URL without uuid
        const modelPath = new URL(modelUrl).pathname;
        if (url.includes(modelPath) && !url.includes('generation_uuid') && !url.includes('auth/login')) {
          await sleep(500);
        } else {
          await chrome.tabs.update(slot.tabId, { url: modelUrl });
          await waitForTabLoad(slot.tabId);
          await sleep(2000);
        }
      } catch(e) { slot.tabId = null; }
    }

    if (!slot.tabId) {
      const newTab = await chrome.tabs.create({ url: modelUrl, active: slot.slotIndex === 0 });
      slot.tabId = newTab.id;
      await waitForTabLoad(slot.tabId);
      await sleep(2500);
    }

    // P7 FIX: Check if login page
    try {
      const tab = await chrome.tabs.get(slot.tabId);
      if (tab.url && (tab.url.includes('auth/login') || tab.url.includes('auth/signin'))) {
        addLog('🔐 Please login to GeminiGen first!', 'err');
        notify('HM_LOGIN_REQUIRED', {});
        slot.status = 'idle';
        state.nextScriptIndex = Math.min(state.nextScriptIndex, scriptIdx);
        return;
      }
    } catch(e) {}

    slot.status = 'generating';
    slot.generatingStartTime = Date.now();
    await runAutomationInSlot(slot, script);

  } catch(e) {
    addLog('❌ Script ' + (scriptIdx+1) + ' error: ' + e.message, 'err');
    slot.status = 'idle';
    if (state.isRunning && !state.softStop) setTimeout(() => startNextInSlot(slot), 5000);
    else checkAllDone();
  }
}

function checkAllDone() {
  const allIdle = state.slots.every(s => s.status === 'idle' || s.status === 'waiting_limit');
  const noMore = state.nextScriptIndex >= state.scripts.length;
  if (!allIdle || !noMore) return;

  if (state.softStop) {
    saveProgress();
    saveButtonState('stopped');
    saveStatus('Stopped', 'red');
    notify('HM_SOFT_STOPPED', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
    return;
  }

  state.isRunning = false;
  const totalTime = state.sessionStartTime ? Math.round((Date.now() - state.sessionStartTime) / 1000) : 0;
  saveSessionToHistory('done', totalTime);
  clearProgress();
  saveButtonState('done');
  saveStatus('All Done! ✓', 'green');
  notify('HM_DONE', { total: state.scripts.length, done: state.sessionStats.done, errors: state.sessionStats.errors.length, totalTime });
}

function waitForTabLoad(tabId) {
  return new Promise(resolve => {
    function listener(id, info) {
      if (id === tabId && info.status === 'complete') { chrome.tabs.onUpdated.removeListener(listener); resolve(); }
    }
    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(resolve, 15000);
  });
}

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function runAutomationInSlot(slot, scriptText) {
  try {
    await chrome.scripting.executeScript({ target: { tabId: slot.tabId }, func: automationScript, args: [scriptText, state.settings] });
    addLog('⏳ Script ' + (slot.scriptIndex+1) + ' — Waiting for video...', 'info');
  } catch(e) {
    addLog('❌ Script ' + (slot.scriptIndex+1) + ' injection failed: ' + e.message, 'err');
    slot.status = 'idle';
    if (state.isRunning && !state.softStop) setTimeout(() => startNextInSlot(slot), 5000);
    else checkAllDone();
  }
}

function automationScript(scriptText, settings) {
  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }
  async function run() {
    try {
      // P1 FIX: Check for generation failed / max limit errors first
      const bodyText = document.body.innerText || '';
      if (bodyText.includes('Maximum number of processing') || bodyText.includes('maximum') && bodyText.includes('processing')) {
        chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Maximum number of processing generations reached' });
        return;
      }
      if (bodyText.includes('Generation failed') || bodyText.includes('Media not found')) {
        chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation failed — Media not found' });
        return;
      }

      let textarea = null;
      const textareaSelectors = ['textarea[placeholder*="Describe"]','textarea[placeholder*="describe"]','textarea[placeholder*="video"]','textarea[placeholder*="generate"]','textarea[placeholder*="Generate"]','textarea'];
      for (const sel of textareaSelectors) { textarea = document.querySelector(sel); if (textarea) break; }
      if (!textarea) textarea = document.querySelector('[contenteditable="true"]');
      if (!textarea) { chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Input field not found' }); return; }

      textarea.focus(); await sleep(300);
      const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
      if (nativeSetter && nativeSetter.set) { nativeSetter.set.call(textarea, ''); } else { textarea.value = ''; }
      textarea.dispatchEvent(new Event('input', { bubbles: true })); await sleep(200);
      if (nativeSetter && nativeSetter.set) { nativeSetter.set.call(textarea, scriptText); } else { textarea.value = scriptText; }
      textarea.dispatchEvent(new Event('input', { bubbles: true }));
      textarea.dispatchEvent(new Event('change', { bubbles: true })); await sleep(500);

      const btnSelectors = ['button[type="submit"]','button[aria-label*="enerate"]','button[aria-label*="send"]','button[aria-label*="Send"]','button[title*="enerate"]','button[class*="send"]','button[class*="submit"]','button[class*="generate"]','form button:last-child','button svg'];
      let genBtn = null;
      for (const sel of btnSelectors) { const el = document.querySelector(sel); if (el) { genBtn = el.closest('button') || el; break; } }
      if (genBtn) { genBtn.click(); await sleep(500); }
      else { textarea.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, ctrlKey: false, bubbles: true })); await sleep(500); }

      const oldUrl = window.location.href;
      let urlPollCount = 0;
      const urlPollInterval = setInterval(() => {
        urlPollCount++;
        if (urlPollCount > 60) { clearInterval(urlPollInterval); chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation did not start (60s timeout)' }); return; }

        // P1 FIX: Check for errors during polling
        const bodyNow = document.body.innerText || '';
        if (bodyNow.includes('Maximum number of processing')) {
          clearInterval(urlPollInterval);
          chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Maximum number of processing generations reached' });
          return;
        }
        if (bodyNow.includes('Generation failed') || bodyNow.includes('Media not found')) {
          clearInterval(urlPollInterval);
          chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation failed — Media not found' });
          return;
        }

        const currentUrl = window.location.href;
        if ((currentUrl !== oldUrl) && currentUrl.includes('generation_uuid')) {
          clearInterval(urlPollInterval);
          let pollCount = 0;
          const pollInterval = setInterval(async () => {
            pollCount++;
            if (pollCount > 150) { clearInterval(pollInterval); chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Video generation timeout (7.5 min)' }); return; }

            const bt = document.body.innerText || '';
            // P1 FIX: Detect generation failed inside generation page
            if (bt.includes('Generation failed') || bt.includes('Media not found') || bt.includes('try again later')) {
              clearInterval(pollInterval);
              chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Generation failed — Media not found' });
              return;
            }
            if (bt.includes('Maximum number of processing')) {
              clearInterval(pollInterval);
              chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: 'Maximum number of processing generations reached' });
              return;
            }

            if (bt.includes('being created') || bt.includes('AI magic') || bt.includes('being generated')) return;
            const downloadSelectors = ['a[download]','button[aria-label*="ownload"]','button[title*="ownload"]','button[class*="download"]','[data-action*="download"]'];
            let downloadEl = null;
            for (const sel of downloadSelectors) { downloadEl = document.querySelector(sel); if (downloadEl) break; }
            const videoEl = document.querySelector('video[src]:not([src=""])');
            if (downloadEl || videoEl) {
              clearInterval(pollInterval);
              let videoUrl = null;
              const pageTitle = document.title || 'video';
              if (downloadEl) { if (downloadEl.tagName === 'A' && downloadEl.href) videoUrl = downloadEl.href; await sleep(300); downloadEl.click(); await sleep(1000); }
              if (!videoUrl && videoEl) videoUrl = videoEl.src;
              if (!videoUrl) { const allVideos = document.querySelectorAll('video'); for (const v of allVideos) { if (v.src && v.src !== '') { videoUrl = v.src; break; } } }
              chrome.runtime.sendMessage({ action: 'HM_VIDEO_FOUND', videoUrl, tabTitle: pageTitle });
            }
          }, 3000);
        }
      }, 1000);
    } catch (err) { chrome.runtime.sendMessage({ action: 'HM_CONTENT_ERROR', error: err.message }); }
  }
  run();
}

function handleVideoFoundInSlot(slot, videoUrl, tabTitle) {
  const folder = state.settings.folderName || 'HM_Shorts_AI_Videos';
  const ts = Date.now();
  const rawTitle = (state.scriptTitles && state.scriptTitles[slot.scriptIndex]) || '';
  const safeTitle = rawTitle.trim().replace(/[\\/:*?"<>|]/g, '').replace(/\s+/g, '_').substring(0, 80);
  const filename = folder + '/' + (safeTitle || 'video_' + (slot.scriptIndex+1) + '_' + ts) + '.mp4';
  addLog('⬇ Downloading Script #' + (slot.scriptIndex+1), 'dl');

  if (!videoUrl) {
    state.sessionStats.errors.push({ title: rawTitle || ('Script #' + (slot.scriptIndex+1)), error: 'Video URL not found' });
    addLog('⚠ No video URL — skipping Script #' + (slot.scriptIndex+1), 'err');
    notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
    slot.status = 'idle';
    // P2 FIX: Move tab to /veo before next script
    moveTabToModel(slot);
    if (state.isRunning && !state.softStop) startNextInSlot(slot); else checkAllDone();
    return;
  }

  chrome.downloads.download({ url: videoUrl, filename, saveAs: false }, downloadId => {
    if (chrome.runtime.lastError || !downloadId) {
      if (slot.retries < 3) {
        slot.retries++;
        addLog('⚠ Download failed (' + slot.retries + '/3) retrying...', 'info');
        setTimeout(() => handleVideoFoundInSlot(slot, videoUrl, tabTitle), 5000);
      } else {
        state.sessionStats.errors.push({ title: rawTitle || ('Script #' + (slot.scriptIndex+1)), error: 'Download failed 3 times' });
        addLog('❌ 3 retries failed — Script #' + (slot.scriptIndex+1), 'err');
        notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
        slot.status = 'idle';
        moveTabToModel(slot);
        if (state.isRunning && !state.softStop) startNextInSlot(slot); else checkAllDone();
      }
      return;
    }

    addLog('📥 Script #' + (slot.scriptIndex+1) + ' downloading...', 'dl');
    function onDownloadChanged(delta) {
      if (delta.id !== downloadId) return;
      if (delta.state && delta.state.current === 'complete') {
        chrome.downloads.onChanged.removeListener(onDownloadChanged);
        state.sessionStats.done++;
        addLog('✅ Script #' + (slot.scriptIndex+1) + ' done!', 'ok');
        notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
        notify('HM_PROGRESS', { done: state.sessionStats.done, total: state.scripts.length, currentIdx: state.nextScriptIndex });
        saveProgress();
        slot.status = 'idle';
        slot.retries = 0;
        slot.generatingStartTime = null;
        // P2 FIX: Move tab to model URL immediately after download
        moveTabToModel(slot);
        // Also release any waiting_limit slots
        state.slots.forEach(s => {
          if (s.status === 'waiting_limit') {
            s.status = 'idle';
            if (state.isRunning && !state.softStop) startNextInSlot(s);
          }
        });
        if (state.isRunning && !state.softStop) startNextInSlot(slot); else checkAllDone();
      }
      if (delta.state && delta.state.current === 'interrupted') {
        chrome.downloads.onChanged.removeListener(onDownloadChanged);
        if (slot.retries < 3) {
          slot.retries++;
          addLog('⚠ Download interrupted (' + slot.retries + '/3)...', 'info');
          setTimeout(() => handleVideoFoundInSlot(slot, videoUrl, tabTitle), 5000);
        } else {
          state.sessionStats.errors.push({ title: rawTitle || ('Script #' + (slot.scriptIndex+1)), error: 'Download interrupted' });
          addLog('❌ 3 retries failed — Script #' + (slot.scriptIndex+1), 'err');
          notify('HM_STATS', { done: state.sessionStats.done, errors: state.sessionStats.errors.length });
          slot.status = 'idle';
          moveTabToModel(slot);
          if (state.isRunning && !state.softStop) startNextInSlot(slot); else checkAllDone();
        }
      }
    }
    chrome.downloads.onChanged.addListener(onDownloadChanged);
  });
}

// P2 FIX: Move tab back to model URL after download
function moveTabToModel(slot) {
  if (!slot.tabId) return;
  const modelUrl = getModelUrl(state.settings);
  chrome.tabs.get(slot.tabId, tab => {
    if (chrome.runtime.lastError) return;
    if (tab && tab.url && !tab.url.includes(new URL(modelUrl).pathname.split('?')[0])) {
      chrome.tabs.update(slot.tabId, { url: modelUrl });
    }
  });
}

function notify(type, data) { chrome.runtime.sendMessage({ type, ...data }).catch(() => {}); }
