// ===== HM Shorts AI - Side Panel JS =====
// Version: 1.14

// ===== LICENSE SYSTEM =====
const APPS_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbwZEEILv-rgPXnyNwsTNa41KNDqlCBfzAYGD_HW7NMa0w6hldyDa08Y-1vLup5ebICUDQ/exec';

// Device ID — chrome.storage.sync mein save hoga — reinstall ke baad bhi rehta hai!
function getOrCreateDeviceId(callback) {
  chrome.storage.sync.get(['hmDeviceId'], r => {
    if (r.hmDeviceId) {
      callback(r.hmDeviceId);
    } else {
      const id = 'DEV-' + Date.now() + '-' + Math.random().toString(36).substr(2,9).toUpperCase();
      chrome.storage.sync.set({ hmDeviceId: id }, () => callback(id));
    }
  });
}

function doXHR(url, callback) {
  try {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', url, true);
    xhr.onload = function() {
      try { callback(JSON.parse(xhr.responseText)); }
      catch(e) { callback({ status: 'network_error' }); }
    };
    xhr.onerror = function() { callback({ status: 'network_error' }); };
    xhr.ontimeout = function() { callback({ status: 'network_error' }); };
    xhr.timeout = 15000;
    xhr.send();
  } catch(e) { callback({ status: 'network_error' }); }
}

async function verifyKey(key) {
  return new Promise(resolve => {
    getOrCreateDeviceId(deviceId => {
      const url = APPS_SCRIPT_URL + '?action=check&key=' + encodeURIComponent(key) + '&device=' + encodeURIComponent(deviceId);
      doXHR(url, data => resolve(data.status));
    });
  });
}

async function activateKey(key) {
  return new Promise(resolve => {
    getOrCreateDeviceId(deviceId => {
      const url = APPS_SCRIPT_URL + '?action=activate&key=' + encodeURIComponent(key) + '&device=' + encodeURIComponent(deviceId);
      doXHR(url, data => resolve(data.status));
    });
  });
}

function showLicenseMsg(msg, type) {
  const el = document.getElementById('licenseMsg');
  el.textContent = msg;
  el.className = 'license-msg ' + type;
}

function showMainApp() {
  document.getElementById('licenseScreen').classList.add('hidden');
  document.getElementById('revokedScreen').classList.add('hidden');
  const app = document.getElementById('mainApp');
  app.style.display = 'flex';
  initApp();
}

function showRevokedScreen() {
  document.getElementById('licenseScreen').classList.add('hidden');
  document.getElementById('mainApp').style.display = 'none';
  document.getElementById('revokedScreen').classList.remove('hidden');
}

async function checkLicense() {
  // sync se check karo — remove/reinstall ke baad bhi rehta hai
  chrome.storage.sync.get(['hmLicenseKey', 'hmActivated'], async r => {
    if (r.hmActivated && r.hmLicenseKey) {
      const status = await verifyKey(r.hmLicenseKey);
      if (status === 'active' || status === 'already_yours') {
        showMainApp();
      } else if (status === 'revoked') {
        // Revoked — sync se bhi hatao — sirf revoked screen
        chrome.storage.sync.remove(['hmActivated', 'hmLicenseKey']);
        chrome.storage.sync.set({ hmRevoked: true });
        showRevokedScreen();
      } else if (status === 'network_error') {
        // Grace mode — pehle activate tha to chalne do
        // Lekin revoked flag check karo
        chrome.storage.sync.get(['hmRevoked'], rv => {
          if (rv.hmRevoked) { showRevokedScreen(); }
          else { showMainApp(); }
        });
      } else {
        chrome.storage.sync.remove(['hmActivated', 'hmLicenseKey']);
        document.getElementById('licenseScreen').classList.remove('hidden');
      }
    } else {
      // Revoked flag check — agar revoked hai to revoked screen
      chrome.storage.sync.get(['hmRevoked'], rv => {
        if (rv.hmRevoked) { showRevokedScreen(); }
        else { document.getElementById('licenseScreen').classList.remove('hidden'); }
      });
    }
  });
}

async function handleActivation() {
  const key = document.getElementById('licenseInput').value.trim().toUpperCase();
  if (!key) { showLicenseMsg('Please enter your license key.', 'err'); return; }

  const btn = document.getElementById('btnActivate');
  btn.disabled = true;
  btn.textContent = 'Verifying...';
  showLicenseMsg('Checking license key...', 'info');

  const status = await activateKey(key);

  if (status === 'activated' || status === 'already_yours') {
    // sync mein save — permanent!
    chrome.storage.sync.set({ hmLicenseKey: key, hmActivated: true, hmRevoked: false }, () => {
      showLicenseMsg('✅ License activated! Welcome!', 'ok');
      setTimeout(() => showMainApp(), 1200);
    });
  } else if (status === 'used_other_device') {
    showLicenseMsg('❌ This key is already active on another device.', 'err');
    btn.disabled = false;
    btn.textContent = '🔐 Activate License';
  } else if (status === 'revoked') {
    showLicenseMsg('❌ This license key has been revoked.', 'err');
    btn.disabled = false;
    btn.textContent = '🔐 Activate License';
  } else if (status === 'invalid') {
    showLicenseMsg('❌ Invalid license key. Please check and try again.', 'err');
    btn.disabled = false;
    btn.textContent = '🔐 Activate License';
  } else if (status === 'network_error') {
    showLicenseMsg('⚠ Network error. Please check your internet and try again.', 'err');
    btn.disabled = false;
    btn.textContent = '🔐 Activate License';
  }
}

// ===== UPDATE CHECK SYSTEM =====
const CURRENT_VERSION = '1.14';
const VERSION_URL = 'https://raw.githubusercontent.com/helphmmartcenter/hm-shorts-ai/main/version.json';

async function checkForUpdate() {
  try {
    const res = await fetch(VERSION_URL + '?t=' + Date.now());
    const data = await res.json();
    if (data.version && data.version !== CURRENT_VERSION) {
      showUpdateBanner(data.version, data.download_url, data.message || '');
    }
  } catch (e) {
    // No network — silently ignore
  }
}

function showUpdateBanner(newVersion, downloadUrl, message) {
  const old = document.getElementById('updateBanner');
  if (old) return;

  const banner = document.createElement('div');
  banner.id = 'updateBanner';
  banner.style.cssText = `
    position:fixed;top:0;left:0;right:0;z-index:99999;
    background:linear-gradient(135deg,#f59e0b,#ef4444);
    color:white;padding:10px 14px;
    display:flex;align-items:center;justify-content:space-between;
    font-family:'Segoe UI',sans-serif;font-size:11px;font-weight:700;
    box-shadow:0 2px 12px rgba(0,0,0,0.3);
  `;
  banner.innerHTML = `
    <span>🆕 New Update v${newVersion}!</span>
    <div style="display:flex;gap:6px;align-items:center;">
      <button id="btnUpdateRemoveDownload" style="background:white;color:#ef4444;border:none;border-radius:6px;padding:4px 8px;font-size:10px;font-weight:800;cursor:pointer;">
        🔓 Remove License & Download
      </button>
      <button id="btnUpdateClose" style="background:transparent;color:white;border:none;font-size:16px;cursor:pointer;line-height:1;">×</button>
    </div>
  `;
  document.body.prepend(banner);

  document.getElementById('btnUpdateRemoveDownload').addEventListener('click', () => {
    const btn = document.getElementById('btnUpdateRemoveDownload');
    btn.disabled = true;
    btn.textContent = 'Removing...';

    chrome.storage.sync.get(['hmLicenseKey'], r => {
      const key = r.hmLicenseKey;

      // Reset key in sheet — no device check needed (owner removing own key)
      const doReset = (onDone) => {
        if (!key) { onDone(); return; }
        const xhr = new XMLHttpRequest();
        xhr.open('GET', APPS_SCRIPT_URL + '?action=remove&key=' + encodeURIComponent(key), true);
        xhr.onload = xhr.onerror = xhr.ontimeout = () => onDone();
        xhr.timeout = 10000;
        xhr.send();
      };

      doReset(() => {
        // Clear all local data
        chrome.storage.sync.remove(['hmLicenseKey', 'hmActivated', 'hmRevoked', 'hmDeviceId'], () => {
          chrome.storage.local.remove(['hmProgress', 'hmLog', 'hmStatus', 'hmButtonState'], () => {
            // Show success — use alert since showNotification may not be in scope
            btn.textContent = '✅ Done!';
            btn.style.background = '#22c55e';
            btn.style.color = 'white';
            setTimeout(() => chrome.tabs.create({ url: downloadUrl }), 1200);
          });
        });
      });
    });
  });

  document.getElementById('btnUpdateClose').addEventListener('click', () => {
    document.getElementById('updateBanner').remove();
  });
}

// ===== INIT APP (runs after license verified) =====
function initApp() {
  // Check for update
  setTimeout(checkForUpdate, 2000);

  // ===== INFO MODAL =====
  document.getElementById('btnInfo').addEventListener('click', () => {
    document.getElementById('infoOverlay').classList.remove('hidden');
  });
  document.getElementById('btnInfoClose').addEventListener('click', () => {
    document.getElementById('infoOverlay').classList.add('hidden');
  });
  document.getElementById('infoOverlay').addEventListener('click', e => {
    if (e.target === document.getElementById('infoOverlay')) {
      document.getElementById('infoOverlay').classList.add('hidden');
    }
  });
  document.querySelectorAll('.info-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.info-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.info-tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      const target = document.getElementById('info-' + tab.dataset.tab);
      if (target) target.classList.add('active');
    });
  });
function goTab(name) {
  ['setup','scripts','settings','run','history'].forEach(t => {
    document.getElementById('t-'+t).classList.toggle('active', t === name);
    document.getElementById('page-'+t).classList.toggle('active', t === name);
  });
  // Last active tab save karo
  chrome.storage.local.set({ hmLastTab: name });
  if (name === 'history') loadHistory();
}

// ===== AUTO SAVE SCRIPTS =====
function autoSaveScripts() {
  const scriptTexts = scripts.map(s => s.text.trim()).filter(t => t);
  chrome.storage.local.set({ hmScripts: scriptTexts, hmScriptsFull: scripts });
}

// ===== MODE SWITCHING =====
let currentMode = 'single';
function switchMode(mode) {
  currentMode = mode;
  document.getElementById('modeSingle').classList.toggle('active', mode === 'single');
  document.getElementById('modeBulk').classList.toggle('active', mode === 'bulk');
  document.getElementById('singleMode').style.display = mode === 'single' ? 'block' : 'none';
  document.getElementById('bulkMode').style.display = mode === 'bulk' ? 'block' : 'none';
}

// ===== SCRIPTS =====
let scripts = [];

function escHtml(str) {
  if (!str) return '';
  return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function renderScripts() {
  const list = document.getElementById('scriptsList');
  list.innerHTML = '';
  scripts.forEach((s, i) => {
    const d = document.createElement('div');
    d.className = 'script-card';
    d.innerHTML = `
      <div class="script-card-top">
        <div class="script-num">${i+1}</div>
        <input class="script-title-input" placeholder="Title (e.g. The Bone Orchard)" value="${escHtml(s.title)}"/>
        <button class="del-btn" data-idx="${i}">✕</button>
      </div>
      <div class="desc-label">Description</div>
      <textarea placeholder="Script #${i+1} - describe the video...">${escHtml(s.text)}</textarea>
    `;
    d.querySelector('.script-title-input').addEventListener('input', e => { scripts[i].title = e.target.value; autoSaveScripts(); });
    d.querySelector('textarea').addEventListener('input', e => { scripts[i].text = e.target.value; autoSaveScripts(); });
    d.querySelector('.del-btn').addEventListener('click', () => delScript(i));
    list.appendChild(d);
  });
  updateBadge();
}

function updateBadge() {
  document.getElementById('scriptsBadge').textContent = scripts.length + ' scripts';
}

function addScript() {
  scripts.push({ title: '', text: '' });
  autoSaveScripts();
  renderScripts();
  setTimeout(() => {
    const list = document.getElementById('scriptsList');
    list.scrollTop = list.scrollHeight;
    const inputs = list.querySelectorAll('.script-title-input');
    if (inputs.length) inputs[inputs.length-1].focus();
  }, 50);
}

function delScript(i) {
  scripts.splice(i, 1);
  autoSaveScripts();
  renderScripts();
}

function saveScripts() {
  scripts = scripts.filter(s => s.text && s.text.trim());
  const scriptTexts = scripts.map(s => s.text.trim());
  chrome.storage.local.set({ hmScripts: scriptTexts, hmScriptsFull: scripts }, () => {
    renderScripts();
    log('✅ Scripts saved: ' + scripts.length + ' total', 'ok');
  });
}

function clearAllScripts() {
  if (scripts.length === 0) { log('Koi scripts nahi hain.', 'err'); return; }
  if (confirm('Saari ' + scripts.length + ' scripts delete karni hain?')) {
    scripts = [];
    chrome.storage.local.remove(['hmScripts', 'hmScriptsFull'], () => {
      renderScripts();
      log('🗑 Scripts clear ho gayi.', 'err');
    });
  }
}

// ===== BULK ADD =====
function addBulkScripts() {
  const raw = document.getElementById('bulkTextarea').value;
  if (!raw.trim()) { alert('Kuch paste karo pehle!'); return; }

  const lines = raw.split('\n');
  let added = 0;
  let currentTitle = '';
  let currentDesc = [];

  function pushScript() {
    if (currentTitle && currentDesc.length > 0) {
      const desc = currentDesc.join(' ').trim();
      if (desc) { scripts.push({ title: currentTitle, text: desc }); added++; }
    } else if (currentTitle && currentDesc.length === 0) {
      scripts.push({ title: '', text: currentTitle }); added++;
    }
    currentTitle = '';
    currentDesc = [];
  }

  lines.forEach(line => {
    const trimmed = line.trim();
    if (!trimmed) return; // blank lines skip

    // Title: line detect karo
    if (/^title\s*:/i.test(trimmed)) {
      // Pehli wali script save karo agar hai
      if (currentTitle) pushScript();
      currentTitle = trimmed.replace(/^title\s*:\s*/i, '').trim();
      currentDesc = [];
    }
    // Description: line detect karo
    else if (/^description\s*:/i.test(trimmed)) {
      const descText = trimmed.replace(/^description\s*:\s*/i, '').trim();
      if (descText) currentDesc.push(descText);
    }
    // Description continuation — na Title: hai na Description:
    // Agar currentTitle hai toh yeh description ka hissa hai
    else if (currentTitle) {
      currentDesc.push(trimmed);
    }
    // Koi Title: nahi — pehli line title maano
    else {
      currentTitle = trimmed;
      currentDesc = [];
    }
  });

  // Last script bhi push karo
  pushScript();

  if (added > 0) {
    autoSaveScripts();
    renderScripts();
    switchMode('single');
    document.getElementById('bulkTextarea').value = '';
    log('✅ ' + added + ' scripts add ho gayi!', 'ok');
  } else {
    alert('Koi valid script nahi mili.');
  }
}

// ===== COPY PROMPT =====
const HM_PROMPT = `Aap mera Professional AI Script Writer ho.
Pehle mujhse sawaal karo, phir scripts likho.

PEHLE YEH SAWAAL KARO — EK EK KARKE:

1. Kis platform ke liye?
   (YouTube / Facebook / Instagram / TikTok / Multiple)

2. Video ki category?
   (Car Racing / Nature / Technology / Travel / Food /
   Sports / Motivational / Sci-Fi / Fashion / Aur kuch?)

3. Video style?
   (Cinematic / Realistic / Futuristic / Colorful /
   Vintage / Minimalist / Dramatic)

4. Tone?
   (Professional / Inspiring / Energetic / Calm /
   Adventurous / Luxury)

5. Target audience?
   (Kids / Teens / Adults / General / Business)

6. Video ki duration?
   (5 seconds / 8 seconds / 15 seconds / 30 seconds /
   1 minute / 2 minute / Aur kitni?)

7. Kitni scripts chahiye?

8. Koi special requirement?
   (Locations, colors, camera angles, etc.)

---

JAB MAIN JAWAB DE DUN — BILKUL IS TARAH LIKHO:

Title: [Catchy Professional Title]
Description: [Poori detail ek hi line mein — koi line break nahi]
Title: [Agla Title]
Description: [Poori detail ek hi line mein — koi line break nahi]

---

EXAMPLE — BILKUL AISE OUTPUT DENA HAI:

Title: Mountain Storm
Description: A sleek black SUV drives through misty Scottish highlands at dawn, fog rolls across the road as golden sunlight breaks through clouds, camera sweeps from aerial drone view down to close tracking shot alongside the vehicle.
Title: Neon City Rush
Description: A silver sports car accelerates through rain-soaked Tokyo streets at midnight, neon reflections shimmer on wet asphalt, camera starts from ground level then rises to high aerial shot showing full city skyline.
Title: Desert King
Description: A white luxury SUV crests a massive sand dune in Arabian desert at golden hour, dust trails behind as camera pulls back dramatically revealing endless desert stretching to horizon under deep orange sky.

---

NEXT TIME SHORTCUT:
Jab main sirf number bolunga — jaise "10 chahiye" ya
"20 likho" ya "40 de do" — tum seedha utni scripts likho.
Wahi platform, wahi style, wahi duration, wahi tone
use karo jo pehle set hua tha.
Dobara koi sawaal mat poochho — seedha scripts likho.
Naye unique scripts likho — jo pehle likhi woh repeat mat karo.

---

STRICT CONTENT RULES — HAMESHA FOLLOW KARO:

ALLOWED:
- Real locations, nature, vehicles, sports
- Cinematic camera movements
- Professional lighting, weather effects
- Human characters — fully clothed, professional
- Animals in natural habitat
- Architecture, cityscapes, technology

BILKUL NAHI:
- Koi violence, blood, weapons
- Koi sexual ya inappropriate content
- Koi copyrighted characters (Disney, Marvel, etc.)
- Koi real celebrities ya politicians
- Koi religious controversy
- Koi dangerous activities promote karna
- Koi hate speech ya discrimination

PLATFORM SAFETY:
- YouTube: Family-friendly, advertiser-safe
- Facebook: Community standards compliant
- Instagram: Clean visual content only
- TikTok: Youth-safe content

QUALITY RULES:
- Har script UNIQUE ho — repeat bilkul nahi
- Description HAMESHA ek hi line mein — koi line break nahi
- Duration ke mutabiq description detail adjust karo
- Professional vocabulary use karo
- AI video generation ke liye optimized ho
- Google/Meta policies 100% compliant`;

function copyPrompt() {
  navigator.clipboard.writeText(HM_PROMPT).then(() => {
    showNotification('✅ Prompt Copy Ho Gaya!', 'ok');
  }).catch(() => {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = HM_PROMPT;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showNotification('✅ Prompt Copy Ho Gaya!', 'ok');
  });
}

function showNotification(msg, type) {
  // Purani notification hato agar hai
  const old = document.getElementById('hmNotif');
  if (old) old.remove();

  const n = document.createElement('div');
  n.id = 'hmNotif';
  n.textContent = msg;
  n.style.cssText = `
    position:fixed;bottom:16px;left:50%;transform:translateX(-50%);
    background:${type === 'ok' ? '#0fb8a8' : '#f43f5e'};
    color:white;padding:10px 20px;border-radius:20px;
    font-size:12px;font-weight:700;z-index:9999;
    box-shadow:0 4px 16px rgba(0,0,0,0.3);
    animation:slideUp 0.3s ease;
    white-space:nowrap;
  `;
  document.body.appendChild(n);
  setTimeout(() => { if (n.parentNode) n.remove(); }, 2500);
}

function clearBulkInput() {
  document.getElementById('bulkTextarea').value = '';
}

// ===== SETTINGS =====
function saveSettings() {
  const s = {
    aiModel: document.getElementById('aiModel').value,
    aspectRatio: document.getElementById('aspectRatio').value,
    quality: document.getElementById('quality').value,
    duration: document.getElementById('duration').value,
    delayBetween: parseInt(document.getElementById('delayBetween').value) || 8,
    folderName: document.getElementById('folderName').value || 'HM_Shorts_AI_Videos',
    maxConcurrent: parseInt(document.getElementById('maxConcurrent').value) || 1
  };
  chrome.storage.local.set({ hmSettings: s }, () => { log('Settings saved ✓', 'ok'); });
}

function loadSettings() {
  chrome.storage.local.get(['hmSettings'], r => {
    if (!r.hmSettings) return;
    const s = r.hmSettings;
    if (s.aiModel) document.getElementById('aiModel').value = s.aiModel;
    if (s.aspectRatio) document.getElementById('aspectRatio').value = s.aspectRatio;
    if (s.quality) document.getElementById('quality').value = s.quality;
    if (s.duration) document.getElementById('duration').value = s.duration;
    if (s.delayBetween) document.getElementById('delayBetween').value = s.delayBetween;
    if (s.folderName) document.getElementById('folderName').value = s.folderName;
    if (s.maxConcurrent) document.getElementById('maxConcurrent').value = s.maxConcurrent;
  });
}

// ===== WEBSITE =====
function openWebsite() {
  chrome.tabs.create({ url: 'https://geminigen.ai/veo' }, () => {
    log('Opening GeminiGen AI...', 'info');
    setTimeout(checkLoginStatus, 2000);
  });
}

function checkLoginStatus() {
  chrome.tabs.query({ url: 'https://geminigen.ai/*' }, tabs => {
    if (tabs.length > 0) {
      document.getElementById('loginDot').className = 'status-dot green';
      document.getElementById('loginText').textContent = 'Website open — login karein';
    }
  });
}

// ===== RUN =====
let isRunning = false;

function setRunStatus(text, dotType) {
  document.getElementById('runStatusText').textContent = text;
  const dot = document.getElementById('runDot');
  dot.className = 'status-dot' + (dotType ? ' '+dotType : '');
  document.getElementById('headerStatus').textContent = text;
}

function setProgress(done, total, currentIdx) {
  // P4 FIX: Progress based on actual done videos
  const pct = total > 0 ? Math.round(done/total*100) : 0;
  document.getElementById('progressFill').style.width = pct + '%';
  document.getElementById('progressPct').textContent = pct + '%';
  document.getElementById('progressSub').textContent = done + ' / ' + total + ' videos done';
}

function setStats(done, errors) {
  document.getElementById('statDone').textContent = done;
  document.getElementById('statErrors').textContent = errors;
}

function log(msg, type='') {
  const area = document.getElementById('logArea');
  const t = new Date().toLocaleTimeString();
  const d = document.createElement('div');
  d.className = 'log-line ' + type;
  d.textContent = '[' + t + '] ' + msg;
  area.appendChild(d);
  area.scrollTop = area.scrollHeight;
}

// ===== RUN BUTTON STATE =====
// States: 'start' | 'running' | 'stopped' | 'done'
let currentButtonState = 'start';
let sessionStartTime = null;
let savedSessionId = null;

function setButtonState(state) {
  currentButtonState = state;
  chrome.storage.local.set({ hmButtonState: state });

  const btnStart = document.getElementById('btnStart');
  const btnStop = document.getElementById('btnStop');
  const btnResume = document.getElementById('btnResume');
  const btnClear = document.getElementById('btnClear');
  const resumeRow = document.getElementById('resumeRow');
  const completionCard = document.getElementById('completionCard');

  // Sab hide karo pehle
  btnStart.style.display = 'none';
  btnStop.style.display = 'none';
  resumeRow.style.display = 'none';
  if (completionCard) completionCard.style.display = 'none';

  if (state === 'start') {
    btnStart.style.display = 'block';
  } else if (state === 'running') {
    btnStop.style.display = 'block';
  } else if (state === 'stopped') {
    resumeRow.style.display = 'grid';
  } else if (state === 'done') {
    btnStart.style.display = 'block';
    if (completionCard) completionCard.style.display = 'block';
  }
}

function showCompletionCard(total, done, errors, totalTime) {
  const card = document.getElementById('completionCard');
  if (!card) return;
  const mins = Math.floor(totalTime / 60);
  const secs = totalTime % 60;
  const timeStr = mins > 0 ? mins + ' min ' + secs + ' sec' : secs + ' sec';
  const successRate = total > 0 ? Math.round((done / total) * 100) : 0;

  document.getElementById('ccTotal').textContent = total;
  document.getElementById('ccDone').textContent = done;
  document.getElementById('ccErrors').textContent = errors;
  document.getElementById('ccTime').textContent = timeStr;
  document.getElementById('ccRate').textContent = successRate + '%';
  card.style.display = 'block';
}

// ===== RESUME CHECK =====
function startRun() {
  chrome.runtime.sendMessage({ action: 'HM_GET_PROGRESS' }, res => {
    const progress = res && res.progress;
    if (progress && progress.currentIndex > 0 && progress.total > 0) {
      const remaining = progress.total - progress.currentIndex;
      const msg = 'Previous session:  ' + progress.currentIndex + '/' + progress.total + ' complete hui thi.\n\n• Resume — ' + remaining + ' scripts remaining?\n• Fresh Start — start from beginning?';
      if (confirm(msg)) {
        doStart(progress.scripts, progress.scriptTitles, progress.settings,
                progress.currentIndex, progress.sessionStats.done, progress.sessionStats.errors,
                progress.sessionId, progress.sessionStartTime);
      } else {
        doFreshStart();
      }
    } else {
      doFreshStart();
    }
  });
}

function doFreshStart() {
  chrome.storage.local.get(['hmScripts', 'hmScriptsFull', 'hmSettings'], r => {
    const allScripts = r.hmScripts || scripts.map(s => s.text).filter(t => t && t.trim());
    const allTitles = (r.hmScriptsFull || scripts).map(s => s.title || '');
    if (!allScripts || allScripts.length === 0) {
      log('⚠ No scripts found! Add scripts in Scripts tab.', 'err');
      return;
    }
    const settings = r.hmSettings || {
      aiModel: 'veo3fast', aspectRatio: '9:16', quality: '720p',
      duration: '8', delayBetween: 8, folderName: 'HM_Shorts_AI_Videos'
    };
    doStart(allScripts, allTitles, settings, 0, 0, [], Date.now(), Date.now());
  });
}

function doStart(allScripts, allTitles, settings, resumeIndex, resumeDone, resumeErrors, sessionId, startTime) {
  isRunning = true;
  sessionStartTime = startTime || Date.now();
  savedSessionId = sessionId || Date.now();
  setButtonState('running');
  setRunStatus('Running...', 'green');
  setProgress(resumeIndex, allScripts.length);
  setStats(resumeDone, resumeErrors.length);
  if (resumeIndex > 0) {
    log('▶ Resuming from script ' + (resumeIndex+1) + '/' + allScripts.length, 'info');
  } else {
    log('▶ Starting: ' + allScripts.length + ' scripts', 'info');
  }
  chrome.runtime.sendMessage({
    action: 'HM_START',
    scripts: allScripts, scriptTitles: allTitles, settings,
    resumeIndex, resumeDone, resumeErrors,
    sessionId: savedSessionId, sessionStartTime
  });
}

function stopRun() {
  chrome.runtime.sendMessage({ action: 'HM_SOFT_STOP' });
  isRunning = false;
  setButtonState('stopped');
  setRunStatus('Stopping...', 'orange');
  log('⏸ Stop requested — waiting for current task...', 'info');
}

function resumeRun() {
  chrome.runtime.sendMessage({ action: 'HM_GET_PROGRESS' }, res => {
    const progress = res && res.progress;
    if (progress && progress.scripts && progress.scripts.length > 0) {
      // P3 FIX: Resume from next script — currentIndex already saved as next
      doStart(
        progress.scripts, progress.scriptTitles, progress.settings,
        progress.currentIndex,
        progress.sessionStats.done, progress.sessionStats.errors,
        progress.sessionId, progress.sessionStartTime
      );
    } else {
      doFreshStart();
    }
  });
}

function clearRun() {
  chrome.storage.local.remove(['hmProgress', 'hmLog', 'hmStatus', 'hmButtonState']);
  setButtonState('start');
  setRunStatus('Ready to start', '');
  setProgress(0, 0, 0);
  setStats(0, 0);
  // Clear log area
  const logArea = document.getElementById('logArea');
  logArea.innerHTML = '<div class="log-line info">[System] HM Shorts AI v1.5 ready.</div>';
  const card = document.getElementById('completionCard');
  if (card) card.style.display = 'none';
  log('🗑 Cleared — ready for fresh start.', 'info');
}

// ===== HISTORY =====
function loadHistory() {
  chrome.runtime.sendMessage({ action: 'HM_GET_HISTORY' }, res => {
    const history = (res && res.history) || [];
    renderHistory(history);
  });
}

function renderHistory(history) {
  const container = document.getElementById('historyList');
  if (!history || history.length === 0) {
    container.innerHTML = '<div class="history-empty">📭 No history yet.</div>';
    return;
  }
  container.innerHTML = '';
  history.forEach(session => {
    const errorCount = session.errors ? session.errors.length : 0;
    const statusIcon = session.status === 'done' ? '✅' : '⏹';
    const successRate = session.total > 0 ? Math.round((session.done / session.total) * 100) : 0;
    const mins = session.totalTime ? Math.floor(session.totalTime / 60) : 0;
    const secs = session.totalTime ? session.totalTime % 60 : 0;
    const timeStr = mins > 0 ? mins + 'm ' + secs + 's' : (secs + 's');

    const card = document.createElement('div');
    card.className = 'history-card';
    card.innerHTML = `
      <div class="history-card-top">
        <span class="history-status-icon">${statusIcon}</span>
        <div class="history-info">
          <div class="history-date">${session.date} — ${session.time}</div>
          <div class="history-stats-row">
            <span class="h-stat ok">✓ ${session.done} done</span>
            <span class="h-stat ${errorCount > 0 ? 'err' : 'muted'}">✗ ${errorCount} errors</span>
            <span class="h-stat info">${successRate}%</span>
            ${session.totalTime ? '<span class="h-stat muted">⏱ ' + timeStr + '</span>' : ''}
          </div>
        </div>
        <div class="history-total">${session.done}/${session.total}</div>
      </div>
      ${errorCount > 0 ? `<div class="history-errors">${session.errors.map(e => `<div class="history-error-item">❌ ${escHtml(e.title)}</div>`).join('')}</div>` : ''}
    `;
    container.appendChild(card);
  });
}

function clearHistory() {
  if (!confirm('Delete all history?')) return;
  chrome.runtime.sendMessage({ action: 'HM_CLEAR_HISTORY' }, () => {
    renderHistory([]);
    log('🗑 History cleared.', 'err');
  });
}

// ===== MESSAGES FROM BACKGROUND =====
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'HM_LOG') log(msg.text, msg.cls || '');
  if (msg.type === 'HM_STATUS') setRunStatus(msg.text, msg.dot);
  if (msg.type === 'HM_PROGRESS') setProgress(msg.done, msg.total, msg.currentIdx);
  if (msg.type === 'HM_STATS') setStats(msg.done, msg.errors);
  if (msg.type === 'HM_HISTORY_UPDATED') {
    const histPage = document.getElementById('page-history');
    if (histPage && histPage.classList.contains('active')) loadHistory();
  }
  if (msg.type === 'HM_SOFT_STOPPED') {
    isRunning = false;
    setButtonState('stopped');
    setRunStatus('Stopped', 'red');
    setStats(msg.done, msg.errors);
    log('⏹ Stopped — Click Resume or Clear.', 'err');
  }
  if (msg.type === 'HM_DONE') {
    isRunning = false;
    setButtonState('done');
    setRunStatus('All Done! ✓', 'green');
    setProgress(msg.total, msg.total);
    setStats(msg.done, msg.errors);
    showCompletionCard(msg.total, msg.done, msg.errors, msg.totalTime || 0);
    log('🎉 ' + msg.total + ' scripts done! (' + msg.done + ' saved, ' + msg.errors + ' errors)', 'ok');
    goTab('run');
  }
  if (msg.type === 'HM_STOPPED') {
    isRunning = false;
    setButtonState('stopped');
    setRunStatus('Stopped', 'red');
  }
  // P7 FIX: Login required
  if (msg.type === 'HM_LOGIN_REQUIRED') {
    isRunning = false;
    setButtonState('stopped');
    setRunStatus('Login Required!', 'red');
    log('🔐 Please login to GeminiGen AI first, then Resume.', 'err');
    showNotification('🔐 Please login to GeminiGen AI first!', 'err');
  }
});

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  // License buttons
  document.getElementById('btnActivate').addEventListener('click', handleActivation);
  document.getElementById('licenseInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') handleActivation();
  });
  // Check license first
  checkLicense();
});

  chrome.storage.local.get(['hmScripts', 'hmScriptsFull', 'hmLastTab', 'hmLog', 'hmStatus', 'hmButtonState', 'hmProgress'], r => {
    if (r.hmScriptsFull && r.hmScriptsFull.length > 0) {
      scripts = r.hmScriptsFull;
    } else if (r.hmScripts && r.hmScripts.length > 0) {
      scripts = r.hmScripts.map(t => ({ title: '', text: t }));
    } else { scripts = []; }
    renderScripts();

    const logArea = document.getElementById('logArea');
    if (r.hmLog && r.hmLog.length > 0) {
      logArea.innerHTML = '';
      r.hmLog.forEach(line => {
        const d = document.createElement('div');
        d.className = 'log-line ' + (line.cls || '');
        d.textContent = '[' + line.t + '] ' + line.text;
        logArea.appendChild(d);
      });
      logArea.scrollTop = logArea.scrollHeight;
    }

    if (r.hmStatus) setRunStatus(r.hmStatus.text, r.hmStatus.dot);

    if (r.hmProgress) {
      setProgress(r.hmProgress.sessionStats.done, r.hmProgress.total, r.hmProgress.currentIndex);
      setStats(r.hmProgress.sessionStats.done, r.hmProgress.sessionStats.errors.length);
    }

    const savedState = r.hmButtonState || 'start';
    setButtonState(savedState);
    if (r.hmLastTab) goTab(r.hmLastTab);
  });

  loadSettings();
  checkLoginStatus();

  document.getElementById('t-setup').addEventListener('click', () => goTab('setup'));
  document.getElementById('t-scripts').addEventListener('click', () => goTab('scripts'));
  document.getElementById('t-settings').addEventListener('click', () => goTab('settings'));
  document.getElementById('t-run').addEventListener('click', () => goTab('run'));
  document.getElementById('t-history').addEventListener('click', () => goTab('history'));
  document.getElementById('modeSingle').addEventListener('click', () => switchMode('single'));
  document.getElementById('modeBulk').addEventListener('click', () => switchMode('bulk'));
  document.getElementById('btnAddScript').addEventListener('click', addScript);
  document.getElementById('btnSaveScripts').addEventListener('click', saveScripts);
  document.getElementById('btnClearAll').addEventListener('click', clearAllScripts);
  document.getElementById('btnBulkAdd').addEventListener('click', addBulkScripts);
  document.getElementById('btnBulkClear').addEventListener('click', clearBulkInput);
  document.getElementById('btnCopyPrompt').addEventListener('click', copyPrompt);
  document.getElementById('btnOpenSite').addEventListener('click', openWebsite);
  document.getElementById('btnGoScripts').addEventListener('click', () => goTab('scripts'));
  document.getElementById('btnGoSettings').addEventListener('click', () => goTab('settings'));
  document.getElementById('btnGoRun').addEventListener('click', () => goTab('run'));
  document.getElementById('btnSaveSettings').addEventListener('click', saveSettings);
  document.getElementById('btnStart').addEventListener('click', startRun);
  document.getElementById('btnStop').addEventListener('click', stopRun);
  document.getElementById('btnResume').addEventListener('click', resumeRun);
  document.getElementById('btnClear').addEventListener('click', clearRun);
  document.getElementById('btnClearHistory').addEventListener('click', clearHistory);

  chrome.runtime.sendMessage({ action: 'HM_GET_STATE' }, res => {
    if (res && res.isRunning) {
      isRunning = true;
      setButtonState('running');
      setRunStatus('Running...', 'green');
    }
  });
} // end initApp

// ===== INIT =====
document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('btnActivate').addEventListener('click', handleActivation);
  document.getElementById('licenseInput').addEventListener('keydown', e => {
    if (e.key === 'Enter') handleActivation();
  });
  checkLicense();
});
